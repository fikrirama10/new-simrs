<?php

namespace common\models;

use yii\base\Model;
use yii\data\ActiveDataProvider;
use common\models\Klpcm;

/**
 * KlpcmSearch represents the model behind the search form of `common\models\Klpcm`.
 */
class KlpcmSearch extends Klpcm
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'idrawat', 'iddokter', 'status', 'keterbacaan', 'kelengkapan', 'idjenisrawat'], 'integer'],
            [['tgl_kunjungan', 'ketrangan'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Klpcm::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'idrawat' => $this->idrawat,
            'tgl_kunjungan' => $this->tgl_kunjungan,
            'iddokter' => $this->iddokter,
            'status' => $this->status,
            'keterbacaan' => $this->keterbacaan,
            'kelengkapan' => $this->kelengkapan,
            'idjenisrawat' => $this->idjenisrawat,
        ]);

        $query->andFilterWhere(['like', 'ketrangan', $this->ketrangan]);

        return $dataProvider;
    }
}
