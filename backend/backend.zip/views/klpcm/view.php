<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\Klpcm */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Klpcms', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="klpcm-view">
	<div class='box'>
		<div class='box-header with-border'>Klpcm Pasien</div>
		<div class='box-body'>
						<div class="nav-tabs-custom">
				<ul class="nav nav-tabs">
					<li  class="active" class=""><a href="#tab_usia" data-toggle="tab" aria-expanded="false">Kelengkapan</a></li>
					<li class=""><a href="#tab_agama" data-toggle="tab" aria-expanded="false">Upload Dokumen</a></li>
				</ul>
				<div class="tab-content">
					<div class="tab-pane active" id="tab_usia">
						<?= $this->render('_formKelengkapan',[
							'model' => $model,
							'klpcm' => $klpcm,
						]) ?>
					</div>
				<!-- /.tab-pane -->
					<div class="tab-pane" id="tab_agama">
					</div>

				</div>
				<!-- /.tab-content -->
			</div>
		</div>
	</div>
</div>
