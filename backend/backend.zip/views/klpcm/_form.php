<?php 
use yii\helpers\Html;
use yii\widgets\DetailView;
use common\models\PasienStatus;
use common\models\PasienAlamat;
use common\models\RuanganKelas;
use common\models\Ruangan;
use common\models\Rawat;
use common\models\RawatBayar;
use common\models\KategoriPenyakit;
use yii\helpers\Url;
use yii\web\View;
use kartik\select2\Select2;
use yii\web\JsExpression;
use yii\widgets\ActiveForm;
$formatJs = <<< 'JS'
var formatRepo = function (repo) {
    if (repo.loading) {
        return repo.text;
		
    }
    var marckup =repo.nama;   
    return marckup ;
};
var formatRepoSelection = function (repo) {
    return repo.nama || repo.text;
}

JS;
 
// Register the formatting script
$this->registerJs($formatJs, View::POS_HEAD);
 
// script to parse the results into the format expected by Select2
$resultsJs = <<< JS
function (data) {    
    return {
        results: data,
        
    };
}
JS;
?>
<div class="row">
	<div class="col-sm-8">
		<div class="box">
			<div class="box-header with-border"><h4>KLPCM</h4></div>
			<div class="box-body">
				<?php $form = ActiveForm::begin(['options' => ['class' => 'form-horizontal']]); ?>
				<div class="form-group">
					<label class="col-sm-4 control-label">No RM</label>
					<div class="col-sm-3">
						<input type='text' name="RawatSpri[no_rm]" id='no_rm' class='form-control'>
					</div>
					<span class="col-sm-2 input-group-btn">
						<button type="button" id="show-rm" class="btn btn-info btn-sm btn-flat">Cek RM</button>
					</span>
				</div>
				
				<div class="form-group">
					<label class="col-sm-4 control-label"></label>
					<div class="col-sm-8">
						
					</div>
				</div>
				<div id='ruangan-ajax'></div>
				<div id='icdx'>
				<div class="form-group">
					<label class="col-sm-4 control-label">ICD 10</label>
					<div class="col-sm-5" style='margin-left:15px;'>
						<?= $form->field($klpcm, 'icdx')->widget(Select2::classname(), [
							'name' => 'kv-repo-template',
							'options' => ['placeholder' => 'Cari ICD X .....'],
							'pluginOptions' => [
							'allowClear' => true,
							'minimumInputLength' => 3,
							'ajax' => [
							'url' => "https://simrs.rsausulaiman.com/apites/listdiagnosa",
							'dataType' => 'json',
							'delay' => 250,
							'data' => new JsExpression('function(params) { return {q:params.term};}'),
							'processResults' => new JsExpression($resultsJs),
							'cache' => true
							],
							'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
							'templateResult' => new JsExpression('formatRepo'),
							'templateSelection' => new JsExpression('formatRepoSelection'),
							],
						])->label(false);?>
						  

					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-4 control-label"></label>
					<div class="col-sm-5">
						<?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
					</div>
				</div>
				
				</div>
				<?= $form->field($klpcm, 'tgl_kunjungan')->hiddenInput(['maxlength' => true])->label(false) ?>
				<?= $form->field($klpcm, 'iddokter')->hiddenInput(['maxlength' => true])->label(false) ?>
				<?= $form->field($klpcm, 'idjenisrawat')->hiddenInput(['maxlength' => true])->label(false) ?>
				<?= $form->field($klpcm, 'no_rm')->hiddenInput(['maxlength' => true])->label(false) ?>
				<?= $form->field($klpcm, 'idrawat')->hiddenInput(['maxlength' => true])->label(false) ?>
				<?php ActiveForm::end(); ?>
			</div>
		</div>
	</div>
</div>
<?php
$urlShowPasien = Url::to(['klpcm/show-rm']);
$this->registerJs("
$('#icdx').hide();
	$('#show-rm').on('click',function(){
			$('#ruangan-ajax').hide();
			rm = $('#no_rm').val();
			
			$.ajax({
				type: 'GET',
				url: '{$urlShowPasien}',
				data: 'id='+rm,
				beforeSend: function(){
				// Show image container
				$('#loading').show();
				},
				success: function (data) {				
					$('#ruangan-ajax').show();
					$('#ruangan-ajax').animate({ scrollTop: 0 }, 200);
					$('#ruangan-ajax').html(data);
					
					console.log(data);
					
				},
				complete:function(data){
				// Hide image container
				$('#loading').hide();
				}
			});
		
	});

	
           
	

", View::POS_READY);


?>