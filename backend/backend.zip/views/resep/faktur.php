<?php 
use yii\helpers\Html;
use Picqer\Barcode\BarcodeGeneratorHTML;
use common\models\SettingSimrs;
use common\models\Rawat;
$setting= SettingSimrs::find()->all();
$generator = new \Picqer\Barcode\BarcodeGeneratorPNG();
?>
<?php foreach($setting as $s): ?>
<div class='logo'><?= Html::img(Yii::$app->params['baseUrl'].'/frontend/images/setting/'.$s->logo_rs,['class' => 'img img-responsive']);?></div>
<div class='header2'><div class='h2'> FARMASI <?= $s->nama_rs?></div> <div class='h3'><i><?= $s->alamat_rs?></i></div> <div class='h5'><i>Telepon <?= $s->no_tlp?></i></div></div>
<?php endforeach; ?>
<hr>
<div class='center'><h3>Rincian Resep</h3></div>
<table>
	<tr>
		<td>Nama Pasien</td>
		<td>:</td>
		<td width=250><?= $model->pasien->nama_pasien ?></td>
		<td>Usia</td>
		<td>:</td>
		<td><?= $model->pasien->usia_tahun ?> th</td>
	</tr>
	<tr>
		<td>No RM</td>
		<td>:</td>
		<td><?= $model->pasien->no_rm ?></td>
		<td>Tgl Lahir</td>
		<td>:</td>
		<td><?= $model->pasien->tgllahir ?></td>
	</tr>
	<tr>
		<td>No Resep</td>
		<td>:</td>
		<td><?= $model->kode_resep ?></td>
		
	</tr>
</table>
<hr>
<div class='olab'>
	<table>
		<tr>
			<th>No</th>
			<th>Nama Obat (Merk)</th>
			<th>Qty</th>
			<th>Harga</th>
			<th>Total</th>
		</tr>
		<?php $total=0; $no=1; foreach($resep as $r){ 
			$total += $r->total ;
		?>
		<tr>
			<td><?= $no++ ?></td>
			<td><?= $r->obat->nama_obat?></td>
			<td><?= $r->qty ?></td>
			<td><?= Yii::$app->algo->IndoCurr($r->harga)?></td>
			<td><?= Yii::$app->algo->IndoCurr($r->total)?></td>
		</tr>
		<?php } ?>
		<tr>
			<td colspan=4 align=right>Total Harga</td>
			<th><?= Yii::$app->algo->IndoCurr($total)?></th>
		</tr>
		
	</table>
</div>
<?php if(count($resep_kronis) > 0) { ?>
<pagebreak />
<?php foreach($setting as $s): ?>
<div class='logo'><?= Html::img(Yii::$app->params['baseUrl'].'/frontend/images/setting/'.$s->logo_rs,['class' => 'img img-responsive']);?></div>
<div class='header2'><div class='h2'> FARMASI <?= $s->nama_rs?></div> <div class='h3'><i><?= $s->alamat_rs?></i></div> <div class='h5'><i>Telepon <?= $s->no_tlp?></i></div></div>
<?php endforeach; ?>
<hr>
<div class='center'><h3>Rincian Resep (Kronis)</h3></div>
<table>
	<tr>
		<td>Nama Pasien</td>
		<td>:</td>
		<td width=250><?= $model->pasien->nama_pasien ?></td>
		<td>Usia</td>
		<td>:</td>
		<td><?= $model->pasien->usia_tahun ?> th</td>
	</tr>
	<tr>
		<td>No RM</td>
		<td>:</td>
		<td><?= $model->pasien->no_rm ?></td>
		<td>Tgl Lahir</td>
		<td>:</td>
		<td><?= $model->pasien->tgllahir ?></td>
	</tr>
	<tr>
		<td>No Resep</td>
		<td>:</td>
		<td><?= $model->kode_resep ?></td>
		
	</tr>
</table>
<hr>
<div class='olab'>
	<table>
		<tr>
			<th>No</th>
			<th>Nama Obat (Merk)</th>
			<th>Qty</th>
			<th>Harga</th>
			<th>Total</th>
		</tr>
		<?php $totalrk=0; $no1=1; foreach($resep_kronis as $rk){ 
			$totalrk += $rk->total ;
		?>
		<tr>
			<td><?= $no1++ ?></td>
			<td><?= $rk->obat->nama_obat?></td>
			<td><?= $rk->qty ?></td>
			<td><?= Yii::$app->algo->IndoCurr($rk->harga)?></td>
			<td><?= Yii::$app->algo->IndoCurr($rk->total)?></td>
		</tr>
		<?php } ?>
		<tr>
			<td colspan=4 align=right>Total Harga</td>
			<th><?= Yii::$app->algo->IndoCurr($totalrk)?></th>
		</tr>
		
	</table>
</div>
<?php }?>