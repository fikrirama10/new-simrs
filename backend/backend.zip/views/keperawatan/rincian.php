<?php
	use common\models\TransaksiDetail;
	$total = 0;
?>
<section class="invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
            <i class="fa fa-globe"></i> RINCIAN PASIEN.
            <small class="pull-right">Date: <?= date('d/m/Y')?></small>
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->
      <div class="row invoice-info">
        <div class="col-sm-4 invoice-col">
          Pasien
          <address>
            <strong><?= Yii::$app->kazo->getSbb($model->pasien->usia_tahun,$model->pasien->jenis_kelamin,$model->pasien->idhubungan); ?>. <?= $model->pasien->nama_pasien?></strong><br>
			<p><?= $model->no_rm?></p>
          </address>
        </div>
        <!-- /.col -->
       
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">
          <b>Invoice #<?= $transaksi->idtransaksi?></b><br>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Table row -->
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-bordered">
            <thead>
            <tr>
              <th>Product</th>
              <th>Tarif Rp</th>
              <th>Subtotal Rp</th>
            </tr>
            </thead>
            <tbody>
			<?php foreach($trxdetail as $trx): 
			$detail = TransaksiDetail::find()->where(['idtransaksi'=>$transaksi->id])->andwhere(['DATE_FORMAT(tgl,"%Y-%m-%d")'=>date('Y-m-d',strtotime($trx->tgl))])->all();
			
			?>
				<tr>
				  <th colspan=4><?= date('Y-m-d',strtotime($trx->tgl)) ?></th>
				</tr>
				<?php foreach($detail as $d): 
				$total += $d->total;
				?>
				<tr>
				  <td><?= $d->nama_tindakan ?></td>
				  <td>Rp. <?= Yii::$app->algo->IndoCurr($d->tarif)?></td>
				  <td>Rp. <?= Yii::$app->algo->IndoCurr($d->total)?></td>
				</tr>
				<?php endforeach; ?>
			<?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <div class="row">
        <!-- accepted payments column -->
        <div class="col-xs-6">
         
          <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
            Biaya Administrasi Ranap akan muncul setelah status pasien di pulangkan dari ruangan
          </p>
        </div>
        <!-- /.col -->
        <div class="col-xs-6">
          <p class="lead">Amount Due <?= date('d/m/Y')?></p>

          <div class="table-responsive">
            <table class="table">
              <tbody><tr>
                <th style="width:50%">Subtotal:</th>
                <td>Rp. <?= Yii::$app->algo->IndoCurr($total)?></td>
              </tr>
             
            </tbody></table>
          </div>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- this row will not appear when printing -->
      <div class="row no-print">
        <div class="col-xs-12">
          <a href="invoice-print.html" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
          <button type="button" class="btn btn-success pull-right"> Kembali
          </button>
         
        </div>
      </div>
    </section>