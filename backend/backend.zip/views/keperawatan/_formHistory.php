<?php
	use common\models\SoapRajaldokter;
	use common\models\SoapRajalperawat;
	
	$dokter = SoapRajaldokter::find()->where(['idrawat'=>$rl->id])->one();
	$perawat = SoapRajalperawat::find()->where(['idrawat'=>$rl->id])->one();
?>
<?php if($rl->idjenisrawat != 2){ ?>
<?php if($dokter){ ?>
<h4>Pemeriksaan Dokter</h4>
<table class='table table-bordered'>
	<tr>
		<th width=100>Anamnesa</th>
		<th width=10>:</th>
		<td><?= $dokter->anamnesa ?></td>
	</tr>
	<tr>
		<th width=100>Planing</th>
		<th width=10>:</th>
		<td><?= $dokter->planing ?></td>
	</tr>
</table>
<?php } ?>
<?php if($perawat){ ?>
<h4>Pemeriksaan Perawat</h4>
<table class='table table-bordered'>
	<tr>
		<th width=200>Anamnesa</th>
		<th width=10>:</th>
		<td><?= $perawat->anamnesa ?></td>
	</tr>
	<tr>
		<th width=100>Tekanan Darah</th>
		<th width=10>:</th>
		<td><?= $perawat->sistole ?> / <?= $perawat->distole ?></td>
		<th width=100>Suhu</th>
		<th width=10>:</th>
		<td><?= $perawat->suhu ?> </td>
	</tr>
	<tr>
		<th width=100>Respirasi</th>
		<th width=10>:</th>
		<td><?= $perawat->respirasi ?></td>
		<th width=100>Nadi</th>
		<th width=10>:</th>
		<td><?= $perawat->nadi ?> </td>
	</tr>
	<tr>
		<th width=100>SpO2</th>
		<th width=10>:</th>
		<td><?= $perawat->saturasi ?></td>
		<th width=100>Alergi</th>
		<th width=10>:</th>
		<td><?= $perawat->alergi ?> </td>
	</tr>
</table>
<?php } ?>
<?php } ?>