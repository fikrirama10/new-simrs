<?php 
use yii\helpers\Html;
use common\models\SettingSimrs;
$simrs = SettingSimrs::findOne(3);
?>
<aside class="main-sidebar">

    <section class="sidebar">

        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
				<?php if($simrs){ ?>
					<?= Html::img(Yii::$app->params['baseUrl'].'/frontend/images/setting/'.$simrs->logo_rs, ['alt'=>'no picture', 'class'=>'user-image'])?>
				<?php }else{ ?>
					<?= Html::img(Yii::$app->params['baseUrl'].'/frontend/images/LOGO_RUMKIT_SULAIMAN__2_-removebg-preview.png', ['alt'=>'no picture', 'class'=>'user-image'])?>
				<?php } ?>
            </div>
            <div class="pull-left info">
                <p><?= Yii::$app->user->identity->userdetail->nama ?></p>

                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>

       

	<?php
	$personel=[
					'label' => 'Personel',
					'icon' => 'fas  fa-users',
					'url' => '#',
					'items' => [
						['label' => 'Data Personel', 'icon' => 'fas fa-users', 'url' => ['/personel'],],
						['label' => 'Jabatan', 'icon' => 'fas fa-users', 'url' => ['/personel-jabatan'],],
						['label' => 'Pangkat', 'icon' => 'fas fa-users', 'url' => ['/personel-pangkat'],],
						['label' => 'Profesi', 'icon' => 'fas fa-users', 'url' => ['/personel-profesi'],],
						['label' => 'Jenis', 'icon' => 'fas fa-users', 'url' => ['/personel-jenis'],],
						
						
					],
						['label' => 'Permintaan Barang',
        						'icon' => 'fas  fa-shopping-cart',
        						'url' => '#',
        						'items' => [
									['label' => 'Permintaan Obat / Alkes', 'icon' => 'fas fa-medkit', 'url' => ['/permintaan-obat/unit'],],
									['label' => 'Permintaan Barang', 'icon' => 'fas fa-cart-plus', 'url' => ['/barang-amprah'],],
																		
							        
						        ],
						],	
					
				];
	$humas=[
					'label' => 'Humas',
					'icon' => 'fas  fa-users',
					'url' => '#',
					'items' => [
						['label' => 'Humas', 'icon' => 'fas fa-users', 'url' => ['/'],],
						
						
					],
						['label' => 'Permintaan Barang',
        						'icon' => 'fas  fa-shopping-cart',
        						'url' => '#',
        						'items' => [
									['label' => 'Permintaan Obat / Alkes', 'icon' => 'fas fa-medkit', 'url' => ['/permintaan-obat/unit'],],
									['label' => 'Permintaan Barang', 'icon' => 'fas fa-cart-plus', 'url' => ['/barang-amprah'],],
																		
							        
						        ],
						],	
					
				];
	$pendaftaran=[
					'label' => 'Rekam medis',
					'icon' => 'fas  fa-list',
					'url' => '#',
					'items' => [
						['label' => 'Pendaftaran',
        						'icon' => 'fas  fa-desktop',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Data Pasien', 'icon' => 'fas  fa-file-text-o', 'url' => ['/pasien'],],
									['label' => 'Pendaftaran Pasien Baru', 'icon' => 'fas  fa-file-text-o', 'url' => ['/pasien/create'],],
										['label' => 'Data Pasien Rawat', 'icon' => 'fas  fa-file-text-o', 'url' => ['/pasien/list-poliklinik'],],
									['label' => 'Kuota Pasien', 'icon' => 'fas fa-users', 'url' => ['/pasien/kuota-pasien'],],
									['label' => 'Data Dokter', 'icon' => 'fas fa-users', 'url' => ['/dokter'],],
							        
						        ],
						],
						['label' => 'Admisi',
        						'icon' => 'fas  fa-keyboard-o',
        						'url' => '#',
        						'items' => [
									['label' => 'Ruangan', 'icon' => 'fas fa-users', 'url' => ['/ruangan'],],
									['label' => 'Pindah Ruangan', 'icon' => 'fas fa-users', 'url' => ['/admisi/pindah-ruangan'],],
									['label' => 'Buat SPRI', 'icon' => 'fas fa-users', 'url' => ['/admisi'],],			
									['label' => 'SPRI Jadwal', 'icon' => 'fas fa-users', 'url' => ['/admisi/index-semu'],],			
						        ],
						],
						['label' => 'Statistik',
        						'icon' => 'fas fa-bar-chart',
        						'url' => '#',
        						'items' => [
									['label' => 'Kunjungan Pasien', 'icon' => 'fas fa-users', 'url' => ['/kunjungan-pasien'],],
									['label' => '10 Diagnosa Terbanyak', 'icon' => 'fas fa-users', 'url' => ['/diagnosa'],],									
									['label' => 'Sistem Informasi', 'icon' => 'fas fa-users', 'url' => ['/sistem-informasi'],],	
									['label' => 'Data BOR', 'icon' => 'fas fa-users', 'url' => ['/pasien'],],									
							        
						        ],
						],
						['label' => 'Permintaan Barang',
        						'icon' => 'fas  fa-shopping-cart',
        						'url' => '#',
        						'items' => [
									['label' => 'Permintaan Obat / Alkes', 'icon' => 'fas fa-medkit', 'url' => ['/permintaan-obat/unit'],],
									['label' => 'Permintaan Barang', 'icon' => 'fas fa-cart-plus', 'url' => ['/barang-amprah'],],
																		
							        
						        ],
						],						
					
					],
					
				];
	$rawatjalan=[
			'label' => 'Poliklinik',
					'icon' => 'fas fa-hospital-o',
					'url' => '#',
					'items' => [
						['label' => 'Daftar Pasien',
        						'icon' => 'fas  fa-list',
        						'url' => '#',
        						'items' => [
									['label' => 'Pasien Hari ini', 'icon' => 'fas fa-hospital-o', 'url' => ['/poliklinik'],],
									['label' => 'Semua Pasien', 'icon' => 'fas fa-cart-plus', 'url' => ['/poliklinik/all-pasien'],],							
							        
						        ],
						],	
						['label' => 'Laporan Kunjungan',
        						'icon' => 'fas  fa-list',
        						'url' => '#',
        						'items' => [
									['label' => 'Data Pasien Umum', 'icon' => 'fas fa-hospital-o', 'url' => ['/poliklinik/history-pasien-umum'],],						
									['label' => 'Data Pasien BPJS', 'icon' => 'fas fa-hospital-o', 'url' => ['/poliklinik/history-pasien'],],						
							        
						        ],
						],	
						['label' => 'Permintaan Barang',
        						'icon' => 'fas  fa-shopping-cart',
        						'url' => '#',
        						'items' => [
									['label' => 'Permintaan Obat / Alkes', 'icon' => 'fas fa-medkit', 'url' => ['/permintaan-obat/unit'],],
									['label' => 'Permintaan Barang', 'icon' => 'fas fa-cart-plus', 'url' => ['/barang-amprah'],],
																		
							        
						        ],
						],			
						
					],
	];
	$spri=[
			'label' => 'SPRI',
					'icon' => 'fas fa-hospital-o',
					'url' => '#',
					'items' => [
						['label' => 'SPRI', 'icon' => 'fas fa-hospital-o', 'url' => ['/admisi'],],					
						['label' => 'SPRI Selesai', 'icon' => 'fas fa-hospital-o', 'url' => ['/admisi/index-selesai'],],					
						['label' => 'SPRI Semua', 'icon' => 'fas fa-hospital-o', 'url' => ['//admisi/index-semua'],],					
					],
	];
	$ugd=[
			'label' => 'UGD',
					'icon' => 'fas fa-ambulance',
					'url' => '#',
					'items' => [
						['label' => 'UGD', 'icon' => 'fas fa-money', 'url' => ['/poliklinik/ugd'],],	
						['label' => 'Pasien UGD', 'icon' => 'fas fa-hospital-o', 'url' => ['/poliklinik/all-pasien-ugd'],],
						['label' => 'Permintaan Barang',
        						'icon' => 'fas  fa-shopping-cart',
        						'url' => '#',
        						'items' => [
									['label' => 'Permintaan Obat / Alkes', 'icon' => 'fas fa-medkit', 'url' => ['/permintaan-obat/unit'],],
									['label' => 'Permintaan Barang', 'icon' => 'fas fa-cart-plus', 'url' => ['/barang-amprah'],],
																		
							        
						        ],
						],							
					],
					
					
	];
	$obat=[
			'label' => 'Obat & Alkes',
					'icon' => 'fas fa-medkit',
					'url' => '#',
					'items' => [
						['label' => 'List Obat & Alkes', 'icon' => 'fas fa-money', 'url' => ['/obat'],],					
						['label' => 'List Obat & Alkes Habis', 'icon' => 'fas fa-money', 'url' => ['/obat/barang-habis'],],					
						['label' => 'List Obat & Alkes ED', 'icon' => 'fas fa-money', 'url' => ['/obat/kadaluarsa'],],					
						['label' => 'Obat Keluar Masuk', 'icon' => 'fas fa-money', 'url' => ['/obat/keluar-masuk'],],					
					],
	];
	$tindakan=[
			'label' => 'Tindakan',
					'icon' => 'fas  fa-stethoscope',
					'url' => '#',
					'items' => [
						['label' => 'List Tindakan', 'icon' => 'fas fa-money', 'url' => ['/tindakan'],],					
					],
	];
	$user=[
			'label' => 'User ',
					'icon' => 'fas fa-users',
					'url' => '#',
					'items' => [
						['label' => 'List User', 'icon' => 'fas fa-money', 'url' => ['/user-detail'],],					
					],
	];
	$ok=[
			'label' => 'Kamar OK',
					'icon' => 'fas fa-users',
					'url' => '#',
					'items' => [
						['label' => 'List Operasi ', 'icon' => 'fas fa-money', 'url' => ['/operasi'],],					
					],
				['label' => 'Permintaan Barang',
        						'icon' => 'fas  fa-shopping-cart',
        						'url' => '#',
        						'items' => [
									['label' => 'Permintaan Obat / Alkes', 'icon' => 'fas fa-medkit', 'url' => ['/permintaan-obat/unit'],],
									['label' => 'Permintaan Barang', 'icon' => 'fas fa-cart-plus', 'url' => ['/barang-amprah'],],
																		
							        
						        ],
						],
	];
	$radiologi=[
			'label' => 'Radiologi',
					'icon' => 'fas fa-certificate',
					'url' => '#',
					'items' => [
						['label' => 'Radiologi', 'icon' => 'fas fa-certificate', 'url' => ['/radiologi-order'],],	
						['label' => 'Laporan radiologi',
        						'icon' => 'fas  fa-file',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Laporan', 'icon' => 'fas  fa-file-text-o', 'url' => ['/radiologi-order/laporan'],],
							        
						        ],
						],
						
						['label' => 'Konfigurasi',
        						'icon' => 'fas fa-gears',
        						'url' => '#',
        						'items' => [
						           	['label' => 'List Layanan radiologi', 'icon' => 'fas  fa-file-text-o', 'url' => ['/radiologi'],],
							        
						        ],
						],
						['label' => 'Permintaan Barang',
        						'icon' => 'fas  fa-shopping-cart',
        						'url' => '#',
        						'items' => [
									['label' => 'Permintaan Obat / Alkes', 'icon' => 'fas fa-medkit', 'url' => ['/permintaan-obat/unit'],],
									['label' => 'Permintaan Barang', 'icon' => 'fas fa-cart-plus', 'url' => ['/barang-amprah'],],
																		
							        
						        ],
						],	
						
					],
	];

	$lab=[
			'label' => 'Laboratorium',
					'icon' => 'fas  fa-flask',
					'url' => '#',
					'items' => [
						['label' => 'Pelayanan Lab', 'icon' => 'fas fa-money', 'url' => ['/laboratorium'],],
						['label' => 'Laporan Lab',
        						'icon' => 'fas  fa-money',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Laporan', 'icon' => 'fas  fa-file-text-o', 'url' => ['/laboratorium/laporan'],],
							        
						        ],
						],
						['label' => 'Konfigurasi',
        						'icon' => 'fas  fa-cogs',
        						'url' => '#',
        						'items' => [
						           	['label' => 'List Layanan Lab', 'icon' => 'fas  fa-file-text-o', 'url' => ['/laboratorium-layanan'],],
						           	['label' => 'List Pemeriksaam Lab', 'icon' => 'fas  fa-file-text-o', 'url' => ['/laboratorium-pemeriksaan'],],
							        
						        ],
						],
						['label' => 'Permintaan Barang',
        						'icon' => 'fas  fa-shopping-cart',
        						'url' => '#',
        						'items' => [
									['label' => 'Permintaan Obat / Alkes', 'icon' => 'fas fa-medkit', 'url' => ['/permintaan-obat/unit'],],
									['label' => 'Permintaan Barang', 'icon' => 'fas fa-cart-plus', 'url' => ['/barang-amprah'],],
																		
							        
						        ],
						],			
					],
	];
	
	$dokter=[
			'label' => 'Dokter',
					'icon' => 'fas fa-user-md',
					'url' => '#',
					'items' => [
						['label' => 'Data Dokter', 'icon' => 'fas  fa-user-md', 'url' => ['/dokter'],],					
					],
	];
	
	$utitity=[
		'label' => 'Master Data',
					'icon' => 'fas fa-expeditedssl',
					'url' => '#',
					'items' => [
						['label' => 'Data Poli', 'icon' => 'fas fa-h-square', 'url' => ['/poli'],],					
						['label' => 'Data Kelas', 'icon' => 'fas  fa-user-md', 'url' => ['/ruangan-kelas'],],					
						['label' => 'Data Ruangan', 'icon' => 'fas fa-users', 'url' => ['/ruangan'],],					
					],
	];
	$sistem_informasi=[
		'label' => 'Sistem Informasi',
					'icon' => 'fas fa-expeditedssl',
					'url' => '#',
					'items' => [
						['label' => 'Sistem Informasi', 'icon' => 'fas fa-h-square', 'url' => ['/sistem-informasi'],],				
					],
	];
	$keperawatan=[
		'label' => 'Keperawatan',
					'icon' => 'fas fa-expeditedssl',
					'url' => '#',
					'items' => [
						['label' => 'List Pasien', 'icon' => 'fas fa-h-square', 'url' => ['/keperawatan'],],				
						['label' => 'List Pasien Pulang', 'icon' => 'fas fa-h-square', 'url' => ['/keperawatan/list-pulang'],],	
						['label' => 'Permintaan Barang',
        						'icon' => 'fas  fa-shopping-cart',
        						'url' => '#',
        						'items' => [
									['label' => 'Permintaan Obat / Alkes', 'icon' => 'fas fa-medkit', 'url' => ['/permintaan-obat/unit'],],
									['label' => 'Permintaan Barang', 'icon' => 'fas fa-cart-plus', 'url' => ['/barang-amprah'],],
																		
							        
						        ],
						],						
					],
	];
	$gudang=[
		'label' => 'Gudang',
					'icon' => 'fas fa-expeditedssl',
					'url' => '#',
					'items' => [
						['label' => 'Obat / Alkes',
        						'icon' => 'fas  fa-medicine',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Data Obat / Alkes', 'icon' => 'fas  fa-file-text-o', 'url' => ['/obat'],],
									['label' => 'Daftar Permintaan Obat', 'icon' => 'fas  fa-file-text-o', 'url' => ['/permintaan-obat'],],
									['label' => 'Stok Opname Obat', 'icon' => 'fas  fa-file-text-o', 'url' => ['/obat-stokopname'],],
							        
						        ],
						],	
						['label' => 'Barang',
        						'icon' => 'fas  fa-medicine',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Data Permintaan Barang', 'icon' => 'fas  fa-file-text-o', 'url' => ['/gudang/list-amprah'],],
								
							        
						        ],
						],	
						['label' => 'Barang',
        						'icon' => 'fas  fa-money',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Data Barang', 'icon' => 'fas  fa-file-text-o', 'url' => ['/data-barang'],],
									['label' => 'Daftar Permintaan Barang', 'icon' => 'fas  fa-file-text-o', 'url' => ['/barang-amprah'],],
							        
						        ],
						],
						['label' => 'Permintaan Obat / Alkes',
        						'icon' => 'fas  fa-money',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Permintaan alkes keperawatan', 'icon' => 'fas  fa-file-text-o', 'url' => ['/permintaan-obat/unit'],],
						           	['label' => 'Daftar Permintaan Barang', 'icon' => 'fas  fa-file-text-o', 'url' => ['/barang-amprah/unit'],],
							        
						        ],
						],	
						['label' => 'Data Barang Dropping',
        						'icon' => 'fas  fa-money',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Data Obat Droping', 'icon' => 'fas  fa-file-text-o', 'url' => ['/obat-droping'],],
									['label' => 'Obat Droping Transaksi', 'icon' => 'fas  fa-file-text-o', 'url' => ['/obat-droping-transaksi'],],
							        
						        ],
						],
						
					],
	];
	$billing=[
		'label' => 'Billing',
					'icon' => 'fas fa-money',
					'url' => '#',
					'items' => [
						['label' => 'Pembayaran Pasien',
        						'icon' => 'fas  fa-money',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Casa', 'icon' => 'fas  fa-file-text-o', 'url' => ['/billing'],],
									['label' => 'Pembayaran Selesai', 'icon' => 'fas  fa-file-text-o', 'url' => ['/billing/list-selesai'],],
									['label' => 'List Tarif', 'icon' => 'fas  fa-file-text-o', 'url' => ['/tarif'],],
							        
						        ],
						],			
						['label' => 'Permintaan Barang',
        						'icon' => 'fas  fa-money',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Permintaan obat/alkes', 'icon' => 'fas  fa-file-text-o', 'url' => ['/permintaan-obat/unit'],],
									['label' => 'Permintaan ATK', 'icon' => 'fas  fa-file-text-o', 'url' => ['/barang-amprah'],],
							        
						        ],
						],			
					],
	];
	$farmasi=[
		'label' => 'Farmasi',
					'icon' => 'fas fa-money',
					'url' => '#',
					'items' => [
						['label' => 'Resep Pasien', 'icon' => 'fas fa-h-square', 'url' => ['/resep'],],
						['label' => 'Data Resep', 'icon' => 'fas fa-h-square', 'url' => ['/resep/list-resep'],],		
						['label' => 'Stok Opname', 'icon' => 'fas fa-h-square', 'url' => ['/obat-stokopname'],],				
						['label' => 'Permintaan Barang',
        						'icon' => 'fas  fa-shopping-cart',
        						'url' => '#',
        						'items' => [
									['label' => 'Permintaan Obat / Alkes', 'icon' => 'fas fa-medkit', 'url' => ['/permintaan-obat/unit'],],
									['label' => 'Permintaan Barang', 'icon' => 'fas fa-cart-plus', 'url' => ['/barang-amprah'],],
																		
							        
						        ],
						],		
					],
	];
		$dukkes=[
		'label' => 'Dukkes',
					'icon' => 'fas fa-money',
					'url' => '#',
					'items' => [			
						['label' => 'Permintaan Barang',
        						'icon' => 'fas  fa-shopping-cart',
        						'url' => '#',
        						'items' => [
									['label' => 'Permintaan Obat / Alkes', 'icon' => 'fas fa-medkit', 'url' => ['/permintaan-obat/unit'],],
									['label' => 'Permintaan Barang', 'icon' => 'fas fa-cart-plus', 'url' => ['/barang-amprah'],],
																		
							        
						        ],
						],		
					],
	];
	$kajangkes=[
		'label' => 'Kajangkes',
					'icon' => 'fas fa-money',
					'url' => '#',
					'items' => [
	
						['label' => 'Data Barang, Obat & alkes',
        						'icon' => 'fas  fa-money',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Data Obat & Alkes', 'icon' => 'fas  fa-file-text-o', 'url' => ['/obat'],],
									['label' => 'Data Barang', 'icon' => 'fas  fa-file-text-o', 'url' => ['/data-barang'],],
							        
						        ],
						],
						['label' => 'Daftar Permintaan',
        						'icon' => 'fas  fa-money',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Permintaan Obat & Alkes', 'icon' => 'fas  fa-file-text-o', 'url' => ['/jangkes/list-permintaan-obat'],],
									['label' => 'Permintaan Barang', 'icon' => 'fas  fa-file-text-o', 'url' => ['/barang-amprah/list-permintaan'],],
									['label' => 'Permintaan Barang Selesai', 'icon' => 'fas  fa-file-text-o', 'url' => ['/barang-amprah/list-permintaan-setuju'],],
							        ['label' => 'Permintaan Obat Selesai', 'icon' => 'fas  fa-file-text-o', 'url' => ['/jangkes/list-permintaan-setuju'],],
							        
						        ],
						],	
						['label' => 'Permintaan Barang',
        						'icon' => 'fas  fa-money',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Permintaan Obat & Alkes', 'icon' => 'fas  fa-file-text-o', 'url' => ['/permintaan-obat'],],
									['label' => 'Permintaan Barang', 'icon' => 'fas  fa-file-text-o', 'url' => ['/barang-amprah'],],
							        
						        ],
						],							
					],
	];
	$pengadaan=[
		'label' => 'Pengadaan',
					'icon' => 'fas fa-money',
					'url' => '#',
					'items' => [
						['label' => 'Data Barang, Obat & alkes',
        						'icon' => 'fas  fa-money',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Data Obat & Alkes', 'icon' => 'fas  fa-file-text-o', 'url' => ['/obat'],],
									['label' => 'Data Barang', 'icon' => 'fas  fa-file-text-o', 'url' => ['/data-barang'],],
							        
						        ],
						],
						['label' => 'Data Barang Dropping',
        						'icon' => 'fas  fa-money',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Data Obat Droping', 'icon' => 'fas  fa-file-text-o', 'url' => ['/obat-droping'],],
									['label' => 'Obat Droping Transaksi', 'icon' => 'fas  fa-file-text-o', 'url' => ['/obat-droping-transaksi'],],
							        
						        ],
						],
						['label' => 'Daftar Permintaan',
        						'icon' => 'fas  fa-money',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Permintaan Obat & Alkes', 'icon' => 'fas  fa-file-text-o', 'url' => ['/pengadaan/list-barang'],],
									['label' => 'Permintaan Barang', 'icon' => 'fas  fa-file-text-o', 'url' => ['/pengadaan/list-amprah'],],
							        
						        ],
						],	
						['label' => 'Penerimaan',
        						'icon' => 'fas  fa-money',
        						'url' => '#',
        						'items' => [
						           	['label' => 'Penerimaan Obat / Alkes', 'icon' => 'fas  fa-file-text-o', 'url' => ['/penerimaan-barang'],],
									['label' => 'Penerimaan Barang', 'icon' => 'fas  fa-file-text-o', 'url' => ['/barang-penerimaan'],],
							        
						        ],
						],	
						['label' => 'Permintaan Barang',
									'icon' => 'fas  fa-money',
									'url' => '#',
									'items' => [
										['label' => 'Permintaan Obat & Alkes', 'icon' => 'fas  fa-file-text-o', 'url' => ['/permintaan-obat/unit'],],
										['label' => 'Permintaan Barang', 'icon' => 'fas  fa-file-text-o', 'url' => ['/barang-amprah'],],
										
									],
							],
						['label' => 'Data Lainnya',
									'icon' => 'fas  fa-money',
									'url' => '#',
									'items' => [
										['label' => 'Data Suplier', 'icon' => 'fas  fa-file-text-o', 'url' => ['/obat-suplier'],],
										['label' => 'Data Satuan Barang', 'icon' => 'fas  fa-file-text-o', 'url' => ['/data-satuan'],],
										['label' => 'Data Satuan Obat', 'icon' => 'fas  fa-file-text-o', 'url' => ['/obat-satuan'],],
										
									],
							],						
						],
						
	];

	?>
	<?php if(Yii::$app->user->identity->idpriv == 1){ ?>
	<?= dmstr\widgets\Menu::widget(
	[
		'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
		'items' => [
			['label' => 'Menu', 'options' => ['class' => 'header']],			
			['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],				
				$dokter,
				$pendaftaran,	
				$spri,	
				$rawatjalan,
				$ugd,
				$radiologi,
				$farmasi,
				$lab,
				$utitity,
				$obat,
				$tindakan,
				$sistem_informasi,
				$user,
				$gudang,
				$keperawatan,					
				$billing,					
				$personel,					
				$kajangkes,					
				$pengadaan,		
				$personel,		
		
		],
	]
	) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 2){ ?>
		<?= dmstr\widgets\Menu::widget(
	[
		'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
		'items' => [
			['label' => 'Menu', 'options' => ['class' => 'header']],			
			['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],				
				$dokter,
				$pendaftaran,	
				$spri,	
				$rawatjalan,
				$ugd,
				$radiologi,
				$lab,
				$utitity,
				$obat,
				$farmasi,
				$tindakan,
				$sistem_informasi,
				$user,
				$gudang,
				$keperawatan,					
				$billing,					
				$personel,					
				$kajangkes,					
				$pengadaan,	
				$personel,	
		
		],
	]
	) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 3){ ?>
	<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$personel,									
						$sistem_informasi,									
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 4){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$billing,									
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 5){ ?>
	<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
													
						$gudang,									
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 6){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$billing,									
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 7){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$rawatjalan,										
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 8){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$pendaftaran,									
				
				],
			]
			) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 9){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$billing,									
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 10){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$obat,									
						$farmasi,									
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 11){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$keperawatan,										
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 12){ ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 13){ ?>
	<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$ok,										
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 14){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$rawatjalan,										
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 15){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$radiologi,									
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 16){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$lab,									
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 17){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$spri,									
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 18){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$rawatjalan,										
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 24){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$dukkes,										
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 25){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$kajangkes,										
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 26){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$pengadaan,										
				
				],
			]
		) ?>
	<?php }else if(Yii::$app->user->identity->idpriv == 27){ ?>
		<?= dmstr\widgets\Menu::widget(
			[
				'options' => ['class' => 'sidebar-menu', 'data-widget' => 'tree'],
				'items' => [
					['label' => 'Menu', 'options' => ['class' => 'header']],			
					['label' => 'Dashboard', 'icon' => 'fas fa-hospital-o', 'url' => ['/'],],
						$humas,										
				
				],
			]
		) ?>
	<?php } ?>
    </section>

</aside>
