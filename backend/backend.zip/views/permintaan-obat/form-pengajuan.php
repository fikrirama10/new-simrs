<h3><center>Permintaan Barang UNIT <?= $model->unit->unit?></center></h3>
<h5><center><?= $model->kode_permintaan ?> / <?= $model->tgl_permintaan ?></center></h5>
<table>
	<tr>
		<th>No</th>
		<th>Nama Obat / Alkes</th>
		<th>Satuan</th>
		<th>Jumlah Permintaan</th>
		<th>Harga</th>
		<th>Total</th>
	</tr>
	<?php $no=1; $total=0; foreach($request as $r): 
	    $total += $r->total;
	?>
	
	<tr>
		<td><?= $no++ ?></td>
		<td><?= $r->obat->nama_obat ?></td>
		<td><?= $r->obat->satuan->satuan ?></td>
		<td><?= $r->jumlah ?></td>
		<td><?= $r->harga ?></td>
		<td><?= $r->total ?></td>
	</tr>
	<?php endforeach; ?>
	<tr>
	    <td colspan=5>Sub Total</td>
	    <td><?= $total?></td>
	</tr>
</table>
<br>
<div style='float:left; width:50%; text-align:center;'>
	<p>Kepala Ruangan</p>
</div>
<div style='float:left; width:50%; text-align:center;'>
	<p>Kajangkes</p>
</div>
