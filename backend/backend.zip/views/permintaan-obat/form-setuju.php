<h3><center>Permintaan Barang</center></h3>
<h5><center><?= $model->kode_permintaan ?> / <?= $model->tgl_permintaan ?></center></h5>
<h4>Barang Permintaan</h4>
<table>
	<tr>
		<th>No</th>
		<th>Nama Obat / Alkes</th>
		<th>Satuan</th>
		<th>Jumlah Permintaan</th>
		<th>Keterangan</th>
	</tr>
	<?php $no2=1; foreach($request as $r): ?>
	<tr>
		<td><?= $no2++ ?></td>
		<td><?= $r->obat->nama_obat ?></td>
		<td><?= $r->obat->satuan->satuan ?></td>
		<td align='center'><?= $r->jumlah?></td>
		<td><?= $r->keterangan?></td>
	</tr>
	<?php endforeach; ?>
</table>
<br>
<div style='float:left; width:50%; text-align:center;'>
	<p>Kepala Ruangan</p>
</div>
<div style='float:left; width:50%; text-align:center;'>
	<p>Kajangkes</p>
</div>
