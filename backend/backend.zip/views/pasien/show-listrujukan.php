<?php 
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;
use yii\web\View;
use yii\bootstrap\Modal;
use yii\web\JsExpression;
use yii\widgets\DetailView;
?>
<div class="form-group">
	<div class="col-sm-12">
		<table class='table table-bordered'>
			<tr>
				<th>No.</th>
				<th>No.Rujukan</th>
				<th>Tgl.Rujukan</th>
				<th>No.Kartu</th>
				<th>Nama</th>
				<th>PPK Perujuk</th>
				<th>Sub/Spesialis</th>
			</tr>
			<?php if($json['metaData']['code'] != 200 ){?>
			<tr>
				<td colspan=7>Data Rujukan tidak ditemukan</td>
			</tr>
			<tr>
				<td colspan=7><a class='btn btn-danger'>Rujukan Manual/IGD</a></td>
			</tr>
			
			
			<?php }else{ ?>
			<?php $no=1; foreach($json['response']['rujukan'] as $rujukan): ?>
			<tr>
				<td><?= $no++?></td>
				<td><a href='<?= Url::to(['pasien/sep?id='.$rawat->id.'&rujukan='.$rujukan['noKunjungan'].'&tgl='.$rujukan['tglKunjungan'].'&poli='.$rawat->poli->poli.'&faskes='.$faskes])?>' class='btn btn-xs btn-default'><?= $rujukan['noKunjungan'] ?></td>
				<td><?= $rujukan['tglKunjungan'] ?></td>
				<td><?= $rujukan['peserta']['noKartu'] ?></td>
				<td><?= $rujukan['peserta']['nama'] ?></td>
				<td><?= $rujukan['provPerujuk']['nama'] ?></td>
				<td><?= $rujukan['poliRujukan']['nama'] ?></td>
			</tr>
			<?php endforeach; ?>
			<?php } ?>
		</table>
	</div>
</div>