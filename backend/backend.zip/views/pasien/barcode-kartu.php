<?php
use common\models\SettingSimrs;
use Picqer\Barcode\BarcodeGeneratorHTML;
$generator = new \Picqer\Barcode\BarcodeGeneratorPNG();
$setting= SettingSimrs::find()->all();
?>
<div class="label">
	<b><?= Yii::$app->kazo->getSbb($model->usia_tahun,$model->jenis_kelamin,$model->idhubungan); ?>. <?= substr($model->nama_pasien,0,17); ?></b><br>
	<?= $alamat->alamat ?><br>
	<b class='norm'><?= $model->no_rm ?></b><br>
	<?php if(count($setting) < 1){ ?>
	RSAU LANUD SULAIMAN<br>
	<?php }else{ ?>
	<?php foreach($setting as $s): ?>
	<?= $s->nama_rs?><br>
	<?php endforeach; ?>
	<?php } ?>
	<?= '<img src="data:image/png;base64,' . base64_encode($generator->getBarcode($model->no_rm, $generator::TYPE_CODE_128)) . '">'; ?>
</div>

<div class="label">
	<b><?= Yii::$app->kazo->getSbb($model->usia_tahun,$model->jenis_kelamin,$model->idhubungan); ?>. <?= substr($model->nama_pasien,0,17);?></b><br>
	<b class='norm'><?= $model->no_rm ?></b><br>
	<?php if(count($setting) < 1){ ?>
	RSAU LANUD SULAIMAN<br>
	<?php }else{ ?>
	<?php foreach($setting as $s): ?>
	<?= $s->nama_rs?><br>
	<?php endforeach; ?>
	<?php } ?>
	<?= '<img src="data:image/png;base64,' . base64_encode($generator->getBarcode($model->no_rm, $generator::TYPE_CODE_128)) . '">'; ?>
</div>