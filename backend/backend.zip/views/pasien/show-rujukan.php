<br>
<div class='box'>
	<?php if($json['kode'] == 404){?>
		<div class="alert alert-danger alert-dismissible">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<h4><i class="icon fa fa-check-square"></i> Data tidak ditemukan </h4>
		</div>
	<?php } ?>
</div>