<?php
use Picqer\Barcode\BarcodeGeneratorHTML;
$generator = new \Picqer\Barcode\BarcodeGeneratorPNG();
?>
<?php for($a=0; $a < $jumlah; $a++){ ?>
<div class="barcode-pasien">
<span class='rm-label'><?= $model->no_rm ?></span><br>
	<b><?= Yii::$app->kazo->getSbb($model->pasien->usia_tahun,$model->pasien->jenis_kelamin,$model->pasien->idhubungan); ?>. <?= substr($model->pasien->nama_pasien,0,17);?></b><br>
	<a><?= $model->pasien->tgllahir?>  (<?= $model->pasien->usia_tahun ?> thn , <?= $model->pasien->usia_bulan ?> bln <?= $model->pasien->usia_hari ?> hr )</a><br>
	<?= '<img src="data:image/png;base64,' . base64_encode($generator->getBarcode($model->idkunjungan, $generator::TYPE_CODE_128)) . '">'; ?>
	<?= $model->tgl_kunjungan ?>
</div>
<?php } ?>