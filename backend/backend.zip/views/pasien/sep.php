<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use common\models\PasienStatus;
use common\models\PasienAlamat;
use common\models\Rawat;
use yii\helpers\Url;
use yii\web\View;
use kartik\select2\Select2;
use yii\web\JsExpression;
use yii\bootstrap\Modal;
use yii\widgets\ActiveForm;
$this->title = 'SEP';
$this->params['breadcrumbs'][] = ['label' => 'Pasien', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);

$formatJs = <<< 'JS'
var formatRepo = function (repo) {
    if (repo.loading) {
        return repo.text;
		
    }
    var marckup =repo.nama;   
    return marckup ;
};
var formatRepoSelection = function (repo) {
    return repo.nama || repo.text;
}

JS;
 
// Register the formatting script
$this->registerJs($formatJs, View::POS_HEAD);
 
// script to parse the results into the format expected by Select2
$resultsJs = <<< JS
function (data) {    
    return {
        results: data,
        
    };
}
JS;
?>
<br>
<div class='row'>
	<div class='col-md-4'>
		<div class='box'>
			<div class='box-header with-border'><h4>Data Pasien </h4></div>
			<div class='box-body'>
				<?= DetailView::widget([
						'model' => $pasien,
						'attributes' => [
							'no_rm',
							'nik',
							'no_bpjs',
							'nama_pasien',
							'tgllahir',
							'tempat_lahir',
							'nohp',
							'usia_tahun',
							'kepesertaan_bpjs',
							'pekerjaan.pekerjaan',
						],
					]) ?>
			</div>
		</div>
	</div>
	<div class='col-md-8'>
		<?php if($jumlah > 0){ ?>
			<div class="callout callout-info">
                <p>Peserta ini merupakan peserta terindikasi sebagai Kontrol Ulang/Rujuk Internal. <br>Kunjungan ke- <?= $jumlah + 1 ?> Dengan Rujukan yang sama.</p>
			</div>
		<?php } ?>
		<div class='box'>
			<div class='box-header with-border'><h4><?= $rawat->jenisrawat->jenis?></h4></div>
			<div class='box-body'>
				<?php if($selisih2 != 0){ ?>
				<div class="callout callout-warning">
                <h4>Tgl SEP tidak sesuai</h4>

                <p>Silahkan cek kembali tgl kunjungan pasien , dan ajukan approval SEP jika tgl mundur</p>
				</div>
				<a href='<?= Url::to(['pasien/'.$pasien->id])?>' class='btn btn-info'>Kembali</a>
				<?php }else{ ?>
				<?php $form = ActiveForm::begin(['options' => ['class' => 'form-horizontal']]); ?>
					<div class="form-group">
						<label class="col-sm-4 control-label">Spesialis/SubSpesialis</label>
						<div class="col-sm-8">
						<input type='text' class='form-control' readonly value='<?= $rawat->poli->poli ?>'>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-4 control-label">DPJP yang Melayani</label>
						<div class="col-sm-8">
						<input type='text' class='form-control' readonly value='<?= $rawat->dokter->nama_dokter ?>'>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-4 control-label">Tgl.SEP
						</label>
						<div class="col-md-4">
						<div class="input-group">
							<input type="text" class="form-control" id="txttglsep" value="<?= date('Y-m-d',strtotime($rawat->tglmasuk))?>" maxlength="10" disabled="">
							<span class="input-group-addon">
								<span class="fa fa-calendar">
								</span>
							</span>
						</div>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-4 control-label">PPK Asal Rujukan</label>
						<div class="col-sm-8">
						<input type='text' class='form-control' readonly value='<?= $rujukan['response']['rujukan']['provPerujuk']['nama'] ?>'>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-4 control-label">Tgl.Rujukan
						</label>
						<div class="col-md-4">
						<div class="input-group date ">
							<input type="text" class="form-control" id="txttglsep" value="<?= $rujukan['response']['rujukan']['tglKunjungan'] ?>" maxlength="10" disabled="">
							<span class="input-group-addon">
								<span class="fa fa-calendar">
								</span>
							</span>
						</div>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-4 control-label">No. Rujukan</label>
						<div class="col-sm-8">
						<input type='text' class='form-control' readonly value='<?= $rujukan['response']['rujukan']['noKunjungan']?>'>
						</div>
					</div>
					<?php if($jumlah > 0){ ?>
					<div class="form-group">
						<label class="col-sm-4 control-label">No.Surat Kontrol/SKDP</label>
						<div class="col-sm-4 ">
						<div class="input-group ">
						<input type='text' class='form-control'  value=''>
								<a id="cari" class="input-group-addon btn btn-success btn-sm" ><span class="fa fa-search"></span></a>
						</div>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-4 control-label">DPJP Pemberi Surat SKDP/SPRI</label>
						<div class="col-sm-8">
						<input type='text' class='form-control' readonly value=''>
						</div>
					</div>
					<?php } ?>
					<div class="form-group">
						<label class="col-sm-4 control-label">Diagnosa</label>
						<div class="col-sm-6" style='margin-left:15px;'>
								<?= $form->field($rawat, 'icdx')->widget(Select2::classname(), [
									'name' => 'kv-repo-template',
									'options' => ['placeholder' =>$rujukan['response']['rujukan']['diagnosa']['nama'] ],
									'pluginOptions' => [
									'allowClear' => true,
									'minimumInputLength' => 3,
									'ajax' => [
									'url' => "https://simrs.rsausulaiman.com/apites/listdiagnosa",
									'dataType' => 'json',
									'delay' => 250,
									'data' => new JsExpression('function(params) { return {q:params.term};}'),
									'processResults' => new JsExpression($resultsJs),
									'cache' => true
									],
									'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
									'templateResult' => new JsExpression('formatRepo'),
									'templateSelection' => new JsExpression('formatRepoSelection'),
									],
								])->label(false);?>
							</div>
					</div>
					<div class="form-group">
						<label class="col-sm-4 control-label">Catatan</label>
						<div class="col-sm-8">
						<textarea class='form-control' placeholder='ketik catatan apabila ada'></textarea>
						</div>
					</div>
					<div class="box-footer">
						<a href='<?= Url::to(['pasien/'.$pasien->id])?>' class='btn btn-danger pull-left'>Batal</a>
						<button type="submit" id='confirm' class="btn btn-info pull-right ">Simpan</button>
					</div>
				<?php ActiveForm::end(); ?>
				<?php } ?>
			</div>
		</div>
	</div>
</div>