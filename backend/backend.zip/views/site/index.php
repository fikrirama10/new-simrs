<?php

/* @var $this yii\web\View */
use yii\bootstrap\Modal;
$this->title = 'sim-RS';
?>
<div class="site-index">

<div class='box box-body' style='background:#222d32; -webkit-box-shadow: 11px 11px 7px -6px rgba(97,97,97,1);
-moz-box-shadow: 11px 11px 7px -6px rgba(97,97,97,1);
box-shadow: 11px 11px 7px -6px rgba(97,97,97,1);'>
	<h3 style="color:#fff;">Ketersediaan Tempat Tidur</h3><hr/>
</div>
<div class='row'>
	<?php foreach($bed as $b){ ?>
		<a href='#'  data-toggle="modal" data-target="#modal<?= $b['id']?>">
			<div class="col-md-4 col-sm-6 col-xs-12">
			  <div class="info-box" style='-webkit-box-shadow: 11px 11px 7px -6px rgba(97,97,97,1);-moz-box-shadow: 11px 11px 7px -6px rgba(97,97,97,1);box-shadow: 11px 11px 7px -6px rgba(97,97,97,1);'>

				<span class="info-box-icon bg-navy"><i class='fa fa-bed'></i></span>
					
				<div class="info-box-content">
				  <span class="info-box-text"><?= $b['ruangan']?> ( <?= $b['bed']?> BED )</span>
				  <span class="info-box-number"> <?= $b['bed'] - $b['terisi']?>  Kosong</span> 
				  <span class="info-box-text">Kelas <?php if($b['kelas'] == 4){echo 'VIP';}else{echo $b['kelas'];} ?></span>
				</div> 
				
				
				<!-- /.info-box-content -->
			  </div> 
			  <!-- /.info-box -->
			</div>
		</a>
	<?php } ?>
</div>

<div class='box box-body'>
	<h3>Kunjungan Pasien</h3><hr>
	<div class='row'>
		<div class="col-lg-3 col-xs-6">
			<!-- small box -->
			<div class="small-box bg-aqua">
				<div class="inner">
					<h3><?= $kunjungan['pasien']?></h3>

					<p>Pasien Terdaftar</p>
				</div>
			<div class="icon">
				<i class="fa fa-users"></i>
			</div>
				<a class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
			</div>
		</div>
		<div class="col-lg-3 col-xs-6">
		<!-- small box -->
			<div class="small-box bg-red">
				<div class="inner">
					<h3><?= $kunjungan['ugd']?></h3>

					<p>Pasien UGD</p>
				</div>
				<div class="icon">
					<i class="fa fa-ambulance"></i>
				</div>
					<a class="small-box-footer">
						More info <i class="fa fa-arrow-circle-right"></i>
					</a>
			</div>
		</div>
					
		<div class="col-lg-3 col-xs-6">
		<!-- small box -->
			<div class="small-box bg-yellow">
				<div class="inner">
				<h3><?= $kunjungan['ranap']?></h3> 

				<p>Pasien Rawat Inap</p>
				</div>
				<div class="icon">
				<i class="fa fa-hospital-o"></i>
				</div>
				<a href="#" class="small-box-footer">
				More info <i class="fa fa-arrow-circle-right"></i>
				</a>
			</div>
		</div>
					
		<div class="col-lg-3 col-xs-6">
		<!-- small box -->
			<div class="small-box bg-green">
				<div class="inner">
				<h3><?= $kunjungan['rajal']?></h3>

				<p>Pasien Rawat jalan</p>
				</div>
				<div class="icon">
				<i class="fa fa-stethoscope"></i>
				</div>
				<a href="" class="small-box-footer">
				More info <i class="fa fa-arrow-circle-right"></i>
				</a>
			</div>
		</div>							
	</div>
</div>
</div>
<?php

foreach($bed as $b):
	Modal::begin([
		'id' => 'modal'.$b['id'],
		'header' => '<h3>'.$b['ruangan'].'</h3>',
		'size'=>'modal-lg',
		'options'=>[
			'data-url'=>'transaksi',
			'tabindex' => ''
		],
	]);

	echo '<div class="modalContent">'. $this->render('_dataPasien', ['b'=>$b['id']]).'</div>';
	 
	Modal::end();
	
endforeach;

?>