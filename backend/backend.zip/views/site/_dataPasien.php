<?php
	use common\models\Rawat;
	$rawat = Rawat::find()->where(['status'=>2])->andwhere(['idruangan'=>$b])->all();
?>

<table class='table table-bordered'>
	<tr>
		<th>No</th>
		<th>No RM</th>
		<th>Nama Pasien</th>
		<th>Tgl Masuk</th>
		<th>Diagnosa Masuk</th>
	</tr>
	<?php $no=1; foreach($rawat as $r): ?>
	<tr>
		<td><?= $no++ ?></td>
		<td><?= $r->no_rm ?></td>
		<td><?= $r->pasien->nama_pasien ?></td>
		<td><?= $r->tglmasuk ?></td>
		<td><?= $r->icdx ?></td>
	</tr>
	<?php endforeach; ?>
</table> 