<?php 
use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\ArrayHelper;
use yii\bootstrap\Modal;
use yii\helpers\Url;
use yii\web\View;
use kartik\select2\Select2;
use yii\web\JsExpression;
use yii\widgets\ActiveForm;
use kartik\date\DatePicker;
use common\models\RawatBayar;
use common\models\Tarif;
$tarif = Tarif::find()->all();
?>
<div class='row'>
	<div class='col-md-4'>
			<div class='box'>
			<div class='box-header with-border'>
				<h4>Data Pasien</h4>
			</div>
			<div class='box-body'>
				<?= DetailView::widget([
					'model' => $pasien,
					'attributes' => [
						'no_rm',
						'nama_pasien',
						'nohp',
					],
				]) ?>
			</div>
			</div>
			<div class='box'>
			<div class='box-header with-border'>
				<h4>Tarif Pasien</h4>
			</div>
			<div class='box-body'>
				<table class='table table-bordered'>
					<tr>
						<th>No</th>
						<th>Tindakan</th>
						<th>Tarif</th>
						<th>Bayar</th>
						
					</tr>
					<?php $no=1; foreach($tarif_trx as $tt): ?>
					<tr>
						<td width=10><?= $no++?></td>
						<?php if($tt->idpaket == 1){ ?>
							<?php if($tt->idtindakan == 1){ ?>
								<td style='background:#b3a4a4; color:#fff;'><?= $tt->tindakan->nama_tarif?></td>
							<?php }else if($tt->idtindakan == 2){?>
								<td style='background:#8d7878; color:#fff;'><?= $tt->tindakan->nama_tarif?></td>
							<?php }else if($tt->idtindakan == 3){ ?>
								<td style='background:#6f5252; color:#fff;'><?= $tt->tindakan->nama_tarif?></td>
							<?php } ?>
						<td></td>
						<td></td>
						<?php }else{ ?>
						<td><?= $tt->tindakan->nama_tarif?></td>
						<td><?= $tt->tarif?></td>
						<td><?= $tt->bayar->bayar?></td>
						<?php } ?>
					</tr>
					<?php endforeach;?>
					
				</table>
				<br>
				<?php if($model->status == 1){ ?>
				<a href='<?= Url::to(['billing/rincian?id='.$model->id])?>' class='btn btn-warning'>Hitung Rincian</a>
				<?php } ?>
			</div>
		</div>
	</div>
	<div class='col-md-8'>

		<div class='box'>
			<div class='box-header with-border'>
				<h4>Rincian Tarif</h4>
				<a class='btn btn-success btn-xs ' href='<?= Url::to(['billing/tarif-manual?id='.$model->id])?>'>Manual</a>
			</div>
			<div class='box-body'>
			<?php if($model->status == 1){ ?>
			<?php $form = ActiveForm::begin(); ?>
					<div class='row'>
						<div class='col-md-2 col-xs-2 '><span class='pull-right pd-top'>Tarif</span></div>
						<div class='col-md-6 col-xs-6'>
							<div class="input-group">
								<input type="text" readonly id="nama-tarif" name="" class="form-control">
								<a id="manual" data-toggle="modal" data-target="#mdTarif" class="input-group-addon btn btn-success btn-sm" >...</span></a>								
							</div>
						</div>
					</div>
					<div class='row'>
						<div class='col-md-2 col-xs-2 '><span class='pull-right pd-top'>Harga Rp.</span></div>
						<div class='col-md-3 col-xs-3'>
								<input type="text" readonly id="harga-tarif" name="" class="form-control">		
												
						</div>
						<div class='col-md-1 col-xs-1 '><span class='pull-right pd-top'>Jumlah</span></div>
						<div class='col-md-2 col-xs-2'>
						
								<input type="text"  required id="jumlah-tarif" name="TransaksiDetailBill[jumlah]" class="form-control">		
												
						</div>
						
					</div>
					<div class='row'>
						<div class='col-md-2 col-xs-2 '><span class='pull-right pd-top'>Bayar</span></div>
						<div class='col-md-4 col-xs-4'>
							<?= $form->field($tambahan, 'idbayar')->dropDownList(ArrayHelper::map(RawatBayar::find()->all(), 'id', 'bayar'),['prompt'=>'- Pilih Bayar -','required'=>true])->label(false)?>
						</div>						
					</div>
					<div class='row'>
						<div class='col-md-2 col-xs-2 '><span class='pull-right pd-top'></span></div>
						<div class='col-md-4 col-xs-4'>
							<div class="input-group">
								<button id='confirm'>Tambah</button>					
							</div>
						</div>
					</div>
					<?= $form->field($tambahan, 'idtransaksi')->hiddeninput(['value'=>$model->id])->label(false)?>
					<?= $form->field($tambahan, 'tarif')->hiddeninput()->label(false)?>
				
					<?= $form->field($tambahan, 'iddokter')->hiddeninput()->label(false)?>
					<?= $form->field($tambahan, 'idtarif')->hiddeninput()->label(false)?>
					<?= $form->field($tambahan, 'tindakan')->hiddeninput()->label(false)?>
					<?php foreach($tarif as $o){
				$urlGet = Url::to(['billing/get-tarif']);
					$this->registerJs("
					$('#btn{$o->id}').on('click',function(){
						$('#mdTarif').modal('hide');
						id = $('#input{$o->id}').val();
							$.ajax({
							type: 'POST',
							url: '{$urlGet}',
							data: {id: id},
							dataType: 'json',
							success: function (data) {
								if(data !== null){
									var res = JSON.parse(JSON.stringify(data));					
									$('#nama-tarif').val(res.nama_tarif);
									$('#harga-tarif').val(res.tarif);
									$('#transaksidetailbill-idtarif').val(res.id);
									$('#transaksidetailbill-tarif').val(res.tarif);
									$('#transaksidetailbill-tindakan').val(res.nama_tarif);
									$('#jumlah-tarif').focus();
								}else{
									alert('data tidak ditemukan');
								}
							},
							error: function (exception) {
								alert(exception);
							}
						});	
					}) ;


				", View::POS_READY);
				}?>
			<?php ActiveForm::end(); ?>
			<?php } ?>
			<hr>
			<?php $form = ActiveForm::begin(); ?>
				<table class='table table-bordered'>
					<tr>
						<th>No</th>
						<th>Tindakan</th>
						<th>Tarif</th>
						<th>Bayar</th>
						<th>#</th>
					</tr>
					<?php $no=1; foreach($rincian_tarif as $rt): ?>
					<tr>
						<td width=10><?= $no++?></td>
						<td><?= $rt->tindakan ?></td>
						<td><?= Yii::$app->algo->IndoCurr($rt->tarif)?></td>
						<td><?= $rt->bayar->bayar?></td>
						<td> 
						<?php if($model->status == 1){ ?>
						<a href='<?= Url::to(['billing/hapus-rincian?id='.$rt->id])?>' class='btn btn-danger btn-xs'>Hapus</a>
						<?php } ?>
						</td>
					</tr>
					
					<?php endforeach;?>
					<tr>
						<td style="background:#000" colspan=5></td>
					</tr>
					<tr>
						<th  colspan=4>Transaksi Resep</th>
					</tr>
					<tr>
						<th>No</th>
						<th>Kode Resep</th>
						<th>Harga</th>
						<th colspan=2>Tidak ditanggung</th>
					</tr>
					
					<?php $no=1; foreach($model_obat as $mo): ?>
					<tr>
						<td width=10><?= $no++?></td>
						<td><a data-toggle='modal' data-target='#mdResep<?= $mo->id ?>' class='btn btn-default btn-xs'><?= $mo->kode_resep ?></a></td>
						<td><?= $mo->total_harga ?></td>
						<td  colspan=2><?= Yii::$app->algo->IndoCurr($mo->total_bayar)?></td>
					</tr>
					<?php endforeach;?>
					<tr>
						<td style="background:#000" colspan=5></td>
					</tr>
					<tr>
						<th align='right' colspan=2>Total Ditanggung BPJS</th>
						<th><?= Yii::$app->algo->IndoCurr($rincian_tarif_bpjs + $model_obat_bpjs)?></th>
					</tr>
					<tr>
						<th align='right' colspan=2>Total Tidak ditanggung</th>
						<th><?= $rincian_tarif_umum + $model_obat_bayar ?> <input id='total'type='hidden' value='<?= $rincian_tarif_umum + $model_obat_bayar ?>'></th>
					</tr>
					<?php if($model->status == 1){ ?>
					<tr>
						<th align='right' colspan=2>Diskon Rp</th>
						<th><input name='Transaksi[diskon]' id='diskon'type='text'></th>
					</tr>
					<tr>
						<th align='right' colspan=2>Total Bayar Rp</th>
						<th><input value=0  name='Transaksi[total_bayar]' type='text' id='bayar' readonly><button id='confirm'>Bayar</button></th>
					</tr>
					<?php }else{ ?>
					<tr>
						<td colspan=4><a target='_blank' href='<?= Url::to(['billing/faktur?id='.$model->id])?>' class='btn btn-success'>Print Faktur</a> <a href='<?= Url::to(['billing/edit-faktur?id='.$model->id])?>' class='btn btn-primary'>Edit Faktur</a></td>
					</tr>
					<?php } ?>
				</table>
				<?= $form->field($model, 'total')->hiddeninput(['value'=>$rincian_tarif_bpjs + $model_obat_bpjs + $rincian_tarif_umum + $model_obat_bayar])->label(false) ?>
				<?= $form->field($model, 'total_ditanggung')->hiddeninput(['value'=>$rincian_tarif_bpjs + $model_obat_bpjs ])->label(false) ?>
				<?php ActiveForm::end(); ?>
			</div>
		</div>
	</div>
</div>



<?php 
$this->registerJs("
	$('#diskon').on('keyup',function(){
			jumlah = $('#total').val();	
			diskon = $('#diskon').val();
			subtotal = jumlah - diskon;
			$('#bayar').val(subtotal);
		});
	$('#confirm').on('click', function(event){
		age = confirm('Yakin Untuk menyelesaikan transaksi?? , Transaksi yang sudah selesai tidak dapat di edit lagi .....');
		if(age == true){
			 return true;
		} else {
			event.preventDefault();
		}
	});

", View::POS_READY);

foreach($model_obat as $pl):
	Modal::begin([
		'id' => 'mdResep'.$pl->id,
		'header' => '<h3>Rincian Obat</h3>',
		'size'=>'modal-lg',
		'options'=>[
			'data-url'=>'transaksi',
			'tabindex' => ''
		],
	]);

	echo '<div class="modalContent">'. $this->render('_formObat', ['model'=>$model,'pl'=>$pl]).'</div>';
	 
	Modal::end();

endforeach;

Modal::begin([
		'id' => 'mdTarif',
		'header' => '<h3>Tambah Tindakan</h3>',
		'size'=>'modal-lg',
		'options'=>[
			'data-url'=>'transaksi',
			'tabindex' => '-1'
		],
	]);

	echo '<div class="modalContent">'. $this->render('_formTarif', ['model'=>$model,'tambahan'=>$tambahan]).'</div>';
	 
	Modal::end();

	Modal::begin([
		'id' => 'mdTarifM',
		'header' => '<h3>Tambah Tarif Manual</h3>',
		'size'=>'modal-lg',
		'options'=>[
			'data-url'=>'transaksi',
			'tabindex' => '-1'
		],
	]);

	echo '<div class="modalContent">'. $this->render('_formManual', ['model'=>$model,'tambah_dua'=>$tambah_dua]).'</div>';
	 
	Modal::end();

?>