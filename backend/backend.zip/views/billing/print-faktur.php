<?php 
use yii\helpers\Html;
use common\models\PasienAlamat;
use common\models\SettingSimrs;
use common\models\ObatTransaksi;
use common\models\ObatTransaksiDetail;
$total = 0;
$obat = ObatTransaksi::find()->where(['idtrx'=>$model->id])->all();
$setting= SettingSimrs::find()->all();
use Picqer\Barcode\BarcodeGeneratorHTML;

?>
<div class="header">
	<?php if(count($setting) < 1){ ?>
	<div class="header-logo"><?= Html::img(Yii::$app->params['baseUrl'].'/frontend/images/LOGO RUMKIT BARU.jpg',['class' => 'img img-responsive']);?></div>
	<h1>RUMAH SAKIT TNI AU LANUD SULAIMAN</h1>
	<div class="header-kop">Jl. Terusan Kopo KM 10 No 456 Sulaiman,Kec. Margahayu, <br> Bandung, Jawa Barat 40229<br>Telp. (022) 5409608</div>
	<?php }else{ ?>
			<?php foreach($setting as $s): ?>
			<div class="header-logo"><?= Html::img(Yii::$app->params['baseUrl'].'/frontend/images/setting/'.$s->logo_rs,['class' => 'img img-responsive']);?></div>
			<div class="header-kop"><h2><?= $s->nama_rs?></h2><?= $s->alamat_rs?><br>Tlp: <?= $s->no_tlp?></div>
			<?php endforeach; ?>
			<div class='header-kop2'><h3>RINCIAN BIAYA PASIEN</h3></div>
	<?php } ?>
</div>

<div class="datapasien">
	<table style='font-size:10px;'>
		<tr>
			<td>Nama Pasien</td>
			<td>:</td>
			<td width=150px><?= $pasien->nama_pasien ?></td>
			
			<td>No Faktur</td>
			<td>:</td>
			<td><?= $model->idtransaksi	?></td>
		</tr>
		<tr>
			<td>Tgl Lahir</td>
			<td>:</td>
			<td width=150px><?= $pasien->tgllahir ?></td>
			
			<td>Tgl</td>
			<td>:</td>
			<td><?= $model->tgl_masuk ?> s/d <?= $model->tgl_keluar?></td>
		</tr>
		
		<tr>
			<td>No RM</td>
			<td>:</td>
			<td width=250px><?= $pasien->no_rm ?></td>
			
			
		</tr>
		
		
	</table>
</div>
<br>
<?php foreach($obat as $o){
			$total += $o->total_harga;
		} ?>
<div class='olab'>
	<table>
		<tr>
			<td style='border-top:1px solid; font-size:9px;background:#ececec; border-bottom:1px solid; text-transform:uppercase;' colspan=4><b>Deskripsi</b></td>
			<td align=right style='background:#ececec; border-bottom:1px solid; border-top:1px solid; font-size:9px; text-transform:uppercase;' colspan=2><b>TOTAL</b></td>
		</tr>
		<tr>
			<td style='text-transform:uppercase;' colspan=4><b>tindakan dan layanan medis</b></td>
			<td align=right  style='text-transform:uppercase; font-size:11px; ' colspan=2><b> <?= Yii::$app->algo->IndoCurr($model->total - $total)?></b></td>
		</tr>
		<?php foreach($model_detail as $md){ ?>
		<tr>
			<td></td>
			<td style='font-size:11px;'><?= $md->tindakan ?></td>
			<td></td>
			<td>:</td>
			<td style='font-size:11px;' > <?= Yii::$app->algo->IndoCurr($md->tarif )?></td>
		</tr>
		<?php } ?>
		
		<tr>
			<td style='text-transform:uppercase;' colspan=4><b>Alkes & Obat obatan</b></td>
			<td align=right  style='text-transform:uppercase; font-size:11px; ' colspan=2><b> <?= Yii::$app->algo->IndoCurr($total)?></b></td>
		</tr>
		<?php foreach($obat as $o){ 
		$obat_detail = ObatTransaksiDetail::find()->where(['idtrx'=>$o->id])->all();
		?>
		<tr>
			<td></td>
			<td><?= $o->kode_resep ?>
				<ul>
				<?php foreach($obat_detail as $od){ ?>
				  <li><?= $od->obat->nama_obat?> (<?= $od->bacth->merk?>)</li>
				<?php }?>
				</ul>  

			</td>
			<td></td>
			<td>:</td>
			<td style='font-size:11px;' > <?= Yii::$app->algo->IndoCurr($o->total_harga )?>
			
			</td>
		</tr>
		<?php } ?>
		<tr><td colspan=6></td></tr>
		<tr><td style='text-transform:uppercase; border-top:1px solid; font-size:13px; ' align='right' colspan=6><b><?= Yii::$app->algo->IndoCurr($model->total)?></b></td></tr>
	</table>
</div>
<div class='olab'>
<table style='font-size:10px;'>
	<tr>
		<td>Total Tagihan</td>
		<td>:</td>
		<td><?= Yii::$app->algo->IndoCurr($model->total)?></td>
		
		<td>Total Diskon %</td>
		<td>:</td>
		<td><?= Yii::$app->algo->IndoCurr($model->diskon)?></td>
	</tr>
	<tr>
		<td>Total Ditanggung (BPJS) </td>
		<td>:</td>
		<td><?= Yii::$app->algo->IndoCurr($model->total_ditanggung)?></td>
		<td>Total yang harus dibayar</td>
		<td>:</td>
		<td><?= Yii::$app->algo->IndoCurr($model->total_bayar)?></td>
	</tr>
	<tr>
		<td>Total Pribadi</td>
		<td>:</td>
		<td><?= Yii::$app->algo->IndoCurr($model->total - $model->total_ditanggung)?></td>
	</tr>
</table>
</div>