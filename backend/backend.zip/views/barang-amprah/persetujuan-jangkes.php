<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use kartik\grid\GridView;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;
use yii\web\View;
use yii\bootstrap\Modal;
/* @var $this yii\web\View */
/* @var $model common\models\BarangAmprah */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Barang Amprahs', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
	<br>
	<div class='row'>
		<div class='col-md-4'>
			<div class='box box-body'>
			<h3>Pengajuan Barang</h3><hr>
				<?= DetailView::widget([
					'model' => $model,
					'attributes' => [
						'tgl_permintaan',
						'unit.unit',
						'amprah.status',
						'keterangan:ntext',
					],
				]) ?>
				<br>
			</div>
		</div>
		<div class='col-md-8'>
			<div class='box box-body'>
				<h3>Daftar Pengajuan Barang</h3><hr>
				<table class='table table-bordered'>
					<tr>
						<th width=10>No</th>
						<th>Nama Barang</th>
						<th>Jumlah Permintaan</th>
						<th>Harga</th>
						<th>Jumlah Disetujui</th>
						<th>Total Pengajuan</th>
						<th>Total Disetujui</th>
						<th>Status</th>
						<th>#</th>
					</tr>
					<?php $no=1; foreach($detail as $d){ ?>
					<tr>
						<td><?= $no++ ?></td>
						<td>
							<?= $d->nama_barang ?>
							<?php if($d->baru == 1){ ?>
								<span class='label label-success'>Baru</span>
							<?php } ?>
						</td>
						<td><?= $d->qty ?> <?php if($d->baru != 1){ ?><?= $d->barang->satuan->satuan ?> <?php } ?> </td>
						<td><?= $d->harga ?></td>
						<td><?= $d->qty_setuju ?></td>
						<td><?= $d->total ?></td>
						<td><?= $d->harga * $d->qty_setuju ?></td>
						<td><?= $d->statuss->status ?></td>
						<td>
							<a  data-toggle='modal' data-target='#mdSetuju<?= $d->id ?>' class='btn btn-xs btn-success'>Setujui</a> 
							<a  data-toggle='modal' data-target='#mdTolak<?= $d->id ?>' class='btn btn-xs btn-danger'>Tolak</a>
							<a  data-toggle='modal' data-target='#mdPermintaan<?= $d->id ?>' class='btn btn-xs btn-primary'>Lihat Stok</a>
						</td>
					</tr>
					<?php } ?>
				</table>
				<br>
				<a href='<?= Url::to(['barang-amprah/selesai-pengajuan?id='.$model->id]) ?>' class='btn btn-primary'>Selesai</a>
		</div>
	</div>
			</div>
	
<?php

foreach($detail as $pl):
	Modal::begin([
		'id' => 'mdPermintaan'.$pl->id,
		'header' => '<h3>Permintaan</h3>',
		'size'=>'modal-lg',
		'options'=>[
			'data-url'=>'transaksi',
			'tabindex' => ''
		],
	]);

	echo '<div class="modalContent">'. $this->render('_formPermintaan', ['model'=>$model,'pl'=>$pl]).'</div>';
	 
	Modal::end();
	Modal::begin([
		'id' => 'mdSetuju'.$pl->id,
		'header' => '<h3>Permintaan Setujui</h3>',
		'size'=>'modal-lg',
		'options'=>[
			'data-url'=>'transaksi',
			'tabindex' => ''
		],
	]);

	echo '<div class="modalContent">'. $this->render('_formSetuju', ['model'=>$model,'pl'=>$pl]).'</div>';
	 
	Modal::end();
	Modal::begin([
		'id' => 'mdTolak'.$pl->id,
		'header' => '<h3>Permintaan Tolak</h3>',
		'size'=>'modal-lg',
		'options'=>[
			'data-url'=>'transaksi',
			'tabindex' => ''
		],
	]);

	echo '<div class="modalContent">'. $this->render('_formTolak', ['model'=>$model,'pl'=>$pl]).'</div>';
	 
	Modal::end();
endforeach;

?>