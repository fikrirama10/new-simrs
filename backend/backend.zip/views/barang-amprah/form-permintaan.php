<h3><center>Permintaan Barang UNIT <?= $model->unit->unit?></center></h3>
<h5><center><?= $model->kode_permintaan ?> / <?= $model->tgl_permintaan ?></center></h5>
<h4>Barang Permintaan</h4>
<table>
	<tr>
		<th>No</th>
		<th>Nama Obat / Alkes</th>
		<th>Satuan</th>
		<th>Jumlah Permintaan</th>
		<th>Keterangan</th>
	</tr>
	<?php $no2=1; foreach($model_list as $r): ?>
	<tr>
		<td><?= $no2++ ?></td>
		<td><?= $r->barang->nama_barang ?></td>
		<td><?= $r->barang->satuan->satuan ?></td>
		<td align='center'><?= $r->qty?></td>
		<td><?= $r->keterangan?></td>
	</tr>
	<?php endforeach; ?>
</table>
<br>
<div style='float:left; width:50%; text-align:center;'>
	<p>Kepala Ruangan</p>
	<br><br><br>
	...........................
</div>
<div style='float:left; width:50%; text-align:center;'>
	<p>Kajangkes</p><br><br><br>
	...........................
</div>
