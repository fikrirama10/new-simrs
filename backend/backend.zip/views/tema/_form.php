<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\SettingSimrsTema */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="setting-simrs-tema-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'tema')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
