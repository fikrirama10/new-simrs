<?php

namespace backend\controllers;

use Yii;
use common\models\Obat;
use common\models\ObatKartustok;
use common\models\ObatBacth;
use common\models\ObatMutasi;
use common\models\GudangInventori;
use common\models\ObatSeacrh;
use common\models\PermintaanObat;
use common\models\BarangAmprahSearch;
use common\models\PermintaanObatdetail;
use common\models\PermintaanObatRequest;
use common\models\PermintaanObatRequestSearch;
use common\models\PermintaanObatdetailSearch;
use common\models\PermintaanObatSearch;
use common\models\BarangAmprah;
use common\models\DataBarang;
use common\models\BarangAmprahDetail;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use kartik\mpdf\Pdf;

/**
 * ObatController implements the CRUD actions for Obat model.
 */
class GudangController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }
    /**
     * Lists all Obat models.
     * @return mixed
     */
    public function actionPenerimaanBarang()
    {
        $searchModel = new ObatSeacrh();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }
	
	public function actionListAmprah(){
		 $searchModel = new BarangAmprahSearch();
		 $where = ['status'=>4];
		 $dataProvider = $searchModel->search(Yii::$app->request->queryParams,$where);
		 return $this->render('list-amrah',[
			'searchModel'=>$searchModel,
			'dataProvider'=>$dataProvider,
		 ]);
	}
	public function actionViewAmprah($id){
		$model = BarangAmprah::findOne($id);
		$detail = BarangAmprahDetail::find()->where(['idamprah'=>$model->id])->all();
		return $this->render('view-amprah',[
			'model'=>$model,
			'detail'=>$detail,
		]);
	}
		public function actionAmprahBerikan($id){
		$detail = BarangAmprahDetail::find()->where(['id'=>$id])->one();
		$barang = DataBarang::findOne($detail->idbarang);
		if($barang->stok < $detail->qty_setuju){
			Yii::$app->session->setFlash('danger', 'stok kurang');
			return $this->redirect(Yii::$app->request->referrer);
		}
		$detail->status = 4;
		if($detail->save()){
			return $this->redirect(Yii::$app->request->referrer);
		}
	}
	public function actionAmprahKoreksi($id){
		$detail = BarangAmprahDetail::find()->where(['id'=>$id])->one();
		$detail->status = 3;
		if($detail->save()){
			return $this->redirect(Yii::$app->request->referrer);
		}
	}
	public function actionAmprahSelesai($id){
		$model = BarangAmprah::find()->where(['id'=>$id])->one();
		$detail = BarangAmprahDetail::find()->where(['idamprah'=>$id])->andwhere(['status'=>4])->all();
		$model->status = 5;
		foreach($detail as $d){
			$barang = DataBarang::findOne($d->idbarang);
			if($barang->stok < $d->qty_setuju){
				Yii::$app->session->setFlash('danger', 'stok kurang');
				return $this->redirect(Yii::$app->request->referrer);
			}else{
				Yii::$app->kazo->mutasiamprah($d->idbarang,1,5,$barang->stok,$d->qty_setuju,12,Yii::$app->user->identity->userdetail->idunit);
				$barang->stok = $barang->stok - $d->qty_setuju;
				$barang->save(false);
			}
			
		}
		if($model->save(false)){
			Yii::$app->session->setFlash('success', 'Pengajuan Di Selesai');
			return $this->redirect(['gudang/list-amprah']);
		}
	}
	public function actionEditItemAmprah($id,$jumlah){
		$detail = BarangAmprahDetail::find()->where(['id'=>$id])->one();
		$detail->qty_setuju = $jumlah;
			if($jumlah < 0){
				$model = 404;
			}else{
				if($detail->save(false)){	
					if($detail->qty_setuju == 0){
						$detail->save();
					}
					$model = "Sukses";
				}
			}
			
		return \yii\helpers\Json::encode($model);
	}
    /**
     * Displays a single Obat model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
		$obat = new ObatBacth();
		$model = $this->findModel($id);
		 if ($obat->load(Yii::$app->request->post()) && $obat->save()) {
            return $this->refresh();
        }
        return $this->render('view', [
            'model' => $model,
            'obat' => $obat,
        ]);
    }

    /**
     * Creates a new Obat model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Obat();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Obat model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Obat model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Obat model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Obat the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Obat::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
