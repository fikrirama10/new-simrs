<?php
namespace backend\controllers;
use Yii;
use yii\base\Model;
use kartik\mpdf\Pdf;
use common\models\Kelurahan;
use common\models\Kecamatan;
use common\models\Provinsi;
use common\models\RawatPermintaanPindah;
use common\models\Rawat;
use common\models\Pasien;
use common\models\Poli;
use common\models\RawatRuangan;
use common\models\Ruangan;
use common\models\Tindakan;
use common\models\RawatRujukan;
use common\models\TindakanTarif;
use common\models\RuanganBed;
use common\models\SoapRajaldokter;
use common\models\SoapRajalperawat;
use common\models\SoapRajalicdx;
use common\models\SoapLab;
use common\models\SoapRadiologi;
use common\models\SoapRajalobat;
use common\models\PasienAlamat;
use common\models\PasienStatus;
use common\models\Dokter;
use common\models\DokterJadwal;
use common\models\DokterKuota;
use common\models\PasienSearch;
use common\models\RawatKunjungan;
use common\models\Transaksi;
use common\models\Tarif;
use common\models\TransaksiDetail;
use common\models\TransaksiDetailRinci;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;


class PasienController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }
	// public function beforeAction($action){
		// if(parent::beforeAction($action)){
			// $headers = Yii::$app->user->identity->idpriv;
			// if($headers == 8 ||  $headers == 17){
				
					// return true;
				
			// }else{
				// return $this->redirect(['/site']);
			// }
		// }
		// throw new \yii\web\UnauthorizedHttpException('Error');
		// return false;
	// }
    public function actionTesRest(){
		$url =Yii::$app->params['baseUrl'].'dashboard/pasien-rest/pasien-sex';
		$content = file_get_contents($url);
		$json = json_decode($content, true);
		
		return print_r($json['agama']);
	 }
     public function actionCreateRujukan($id){
		$rujukan = RawatRujukan::find()->where(['id'=>$id])->one();
		$rawat = Rawat::find()->where(['id'=>$rujukan->idrawat])->one();
		$pasien = Pasien::find()->where(['no_rm'=>$rawat->no_rm])->one();
		return $this->render('create-rujukan',[
			'rujukan'=>$rujukan,
			'rawat'=>$rawat,
			'pasien'=>$pasien,
		]);
	}
	public function actionRujukan(){
		return $this->render('rujukan');
	}
	public function actionShowRujuk($id){
		$rujukan = RawatRujukan::find()->where(['no_rm'=>$id])->andWhere(['status'=>1])->all();
		return $this->renderAjax('show-rujuk',[
			'rujukan'=>$rujukan,
		]);
	}
    public function actionIndex()
    {
		if(Yii::$app->user->isGuest){
			return $this->redirect(['site/logout']);
		}
        $searchModel = new PasienSearch();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }
	public function actionShowRujukan($id){
		$url = Yii::$app->params['baseUrl'].'dashboard/pasien-rest/find-pasien?rm='.$id;
		$content = file_get_contents($url);
		$json = json_decode($content, true);
		if($json['kode'] == 200){
			return $this->redirect(['pasien/'.$json['id']]);
		}else{
			return $this->renderAjax('show-rujukan',[
				'json'=>$json,
			]);
		}
		
	}
	public function actionShowListrujukan($id,$idrawat,$faskes){
		if($faskes == 1){
		$response= Yii::$app->vclaim->get_rujukan_noka($id);
		}else{
		$response= Yii::$app->vclaim->get_rujukan_nokars($id);	
		}
		$rawat = Rawat::findOne($idrawat);
		return $this->renderAjax('show-listrujukan',[
				'json'=>$response,
				'rawat'=>$rawat,
				'faskes'=>$faskes,
		]);
		
		
	}
	function getstatpasien($anggota='',$idpekerjaan='',$idbayar=''){
		if($anggota == 1){
			if($idpekerjaan == 1){
				return 1;
			}else if($idpekerjaan == 2){
				return 2;
			}else{
				return 3;
			}
		}else{
			if($idpekerjaan == 3){
				return 4;
			}else if($idpekerjaan == 4){
				return 5;
			}else if($idpekerjaan == 17){
				return 6;
			}else{
				if($idbayar == 2){
					return 7;
				}else{
					return 8;
				}
			}
		}
	}
	function jenjang_usia($barulahir='',$usia_tahun){
		if($usia_tahun < 1){
			if($barulahir == 1){
				return 1;
			}else{
				return 2;
			}
		}else if($usia_tahun > 0 && $usia_tahun < 4 ){
			return 3;
		}else if($usia_tahun > 3 && $usia_tahun < 11 ){
			return 4;
		}else if($usia_tahun > 10 && $usia_tahun < 20 ){
			return 5;
		}else if($usia_tahun > 19 && $usia_tahun < 41 ){
			return 6;
		}else if($usia_tahun > 40 && $usia_tahun < 60 ){
			return 7;
		}else{
			return 8;
		}
	}
	public function actionKuotaPasien(){
		$tgl = date('Y-m-d',strtotime('+6 hour',strtotime(date('Y-m-d'))));
		$url =Yii::$app->params['baseUrl'].'dashboard/pasien-rest/antrian-pasien?tgl='.$tgl;
		$content = file_get_contents($url);
		$json = json_decode($content, true);
		return $this->render('kuota_pasien',[
			'json'=>$json
		]);
	}
	public function actionShowJadwal($tgl){
		$url =Yii::$app->params['baseUrl'].'dashboard/pasien-rest/antrian-pasien?tgl='.$tgl;
		$content = file_get_contents($url);
		$json = json_decode($content, true);
		return $this->renderAjax('show-jadwal',[
			'json'=>$json
		]);
	}
	function kuota_pasien($tgl,$idpoli,$iddokter){
		$hari = date('N',strtotime($tgl));
			$jadwal = DokterJadwal::find()->where(['iddokter'=>$iddokter])->andwhere(['idhari'=>$hari])->count();
			$jadwal2 = DokterJadwal::find()->where(['iddokter'=>$iddokter])->andwhere(['idhari'=>$hari])->one();
			$kuotac = DokterKuota::find()->where(['iddokter'=>$iddokter])->andwhere(['idhari'=>$hari])->andwhere(['tgl'=>$tgl])->count();
			$kuota = DokterKuota::find()->where(['iddokter'=>$iddokter])->andwhere(['idhari'=>$hari])->andwhere(['tgl'=>$tgl])->one();
			
			if($kuotac == 0 ){
				$newkuota = new DokterKuota();
				$newkuota->iddokter = $iddokter;
				$newkuota->idpoli = $idpoli;
				$newkuota->idhari = $hari;
				$newkuota->tgl = $tgl;
				$newkuota->kuota = $jadwal2->kuota;
				$newkuota->sisa = $jadwal2->kuota - 1;
				$newkuota->terdaftar = 1;
				$newkuota->status = 1;
				$newkuota->save();
			}else{
				if($kuota->sisa == 0){
					return 1;
				}else{
					$kuota->sisa = $kuota->sisa - 1;
					$kuota->terdaftar = $kuota->terdaftar + 1;
					$kuota->save();
					return 2;
				}
				
			}
		
	}
	//Batalkan Kunjungan
	public function actionBatalKunjungan($id){
		$model = RawatKunjungan::find()->where(['id'=>$id])->one();
		$trx = Transaksi::find()->where(['idkunjungan'=>$id])->one();
		$model->status = 5;
		if($model->save()){
			$trx->status = 3;
			$trx->save();
			return $this->redirect(Yii::$app->request->referrer ?: Yii::$app->homeUrl);
		}
		
		
	}
	//Edit Rawat
	public function actionEditRawat($id){
		if(Yii::$app->user->identity->idpriv != 8){
			return $this->redirect(['site/index']);
		}
		$model = Rawat::find()->where(['id'=>$id])->one();
		$pasien = Pasien::find()->where(['no_rm'=>$model->no_rm])->one();
		$tgl = date('Y-m-d',strtotime('+6 hour',strtotime(date('Y-m-d'))));
		$tglkunjungan =date('Y-m-d',strtotime($model->tglmasuk));
		if($tgl != $tglkunjungan ){
			Yii::$app->session->setFlash('warning', 'Pelayanan Tidak bisa diedit Karena tanggal sudah lewat');
			return $this->redirect(Yii::$app->request->referrer ?: Yii::$app->homeUrl);
		}
		if ($model->load($this->request->post())) {
			$model->kat_pasien = $this->getstatpasien($model->anggota,$pasien->idpekerjaan,$model->idbayar);
			if($model->save()){
				return $this->refresh();
			}
		}
		
		return $this->render('edit-rawat',[
			'model'=>$model,
			'pasien'=>$pasien,
		]);
	}
	//Batal Rawat
	public function actionBatalRawat($id){
		if(Yii::$app->user->identity->idpriv != 8){
			return $this->redirect(['site/index']);
		}
		$rawat = Rawat::find()->where(['id'=>$id])->one();
		$trxdetail = TransaksiDetailRinci::find()->where(['idrawat'=>$rawat->id])->all();
		$kunjungan = RawatKunjungan::find()->where(['idkunjungan'=>$rawat->idkunjungan])->one();
		$model = Pasien::find()->where(['no_rm'=>$rawat->no_rm])->one();
		$tgl = date('Y-m-d',strtotime('+6 hour',strtotime(date('Y-m-d'))));
		$tglkunjungan =date('Y-m-d',strtotime($rawat->tglmasuk));
		if($tgl != $tglkunjungan ){
			Yii::$app->session->setFlash('warning', 'Pelayanan Tidak bisa dibatalkan Karena tanggal sudah lewat');
			return $this->redirect(Yii::$app->request->referrer ?: Yii::$app->homeUrl);
		}else{
			if($rawat->load($this->request->post())){
				if($rawat->idjenisrawat == 1){
					$hari  = date('N',strtotime($rawat->tglmasuk));
					$kuota = DokterKuota::find()->where(['iddokter'=>$rawat->iddokter])->andWhere(['idhari'=>$hari])->one();
					$kuota->sisa = $kuota->sisa + 1;
					$kuota->terdaftar = $kuota->terdaftar - 1;
					$kuota->save(false);
				}
				$rawat->status = 5 ;
				
				if($rawat->save(false)){
					foreach($trxdetail as $td){
						$td->delete();
					}
					return $this->redirect(['pasien/rawat-kunjungan?id='.$kunjungan->id]);
				}
			}
			return $this->render('batal-rawat',[
				'model'=>$model,
				'rawat'=>$rawat,
			]);
		}
		
		return $this->render('batal-rawat',[
			'model'=>$model,
			'rawat'=>$rawat,
		]);
	}
	
	
	//Kunjungan Rawat
	public function actionRawatKunjungan($id){		
		$kunjungan = RawatKunjungan::find()->where(['id'=>$id])->one();
		$pindah = RawatPermintaanPindah::find()->where(['idrawat'=>$id])->one();
		$trx = Transaksi::find()->where(['idkunjungan'=>$kunjungan->id])->one();
		$trxdetail = new TransaksiDetail();
		$model = Pasien::find()->where(['no_rm'=>$kunjungan->no_rm])->one();
		$pelayanan = new Rawat();
		$ruangan = new RawatRuangan();
		$kode = $model->no_bpjs;
		$time = date('Y-m-d');
		$tgl = date('Y-m-d');
		$hari = date('N',strtotime($tgl));
		$response= Yii::$app->kazo->bpjs_content('https://new-api.bpjs-kesehatan.go.id:8080/new-vclaim-rest/Peserta/nokartu/'.$kode.'/tglSEP/'.$time.'');
		$data_json=json_decode($response, true);
		$peserta = $data_json['response'];
		$bpjs = $peserta['peserta'];
		if ($pelayanan->load($this->request->post())) {
			if($pelayanan->iddokter == null){
				Yii::$app->session->setFlash('danger', 'Gagal Simpan , Data tidak lengkap');
					return $this->refresh();
			}			
			if($pelayanan->idjenisrawat == 1){
				$pelayanan->status = 1;
				$pelayanan->idruangan = 2;
				$pelayanan->genAntri($pelayanan->idpoli,$pelayanan->iddokter,$pelayanan->anggota,$kunjungan->tgl_kunjungan);
				$jadwal = DokterJadwal::find()->where(['iddokter'=>$pelayanan->iddokter])->andwhere(['idhari'=>$hari])->count();
				$jadwal2 = DokterJadwal::find()->where(['iddokter'=>$pelayanan->iddokter])->andwhere(['idhari'=>$hari])->one();
				$kuotac = DokterKuota::find()->where(['iddokter'=>$pelayanan->iddokter])->andwhere(['idhari'=>$hari])->andwhere(['tgl'=>$tgl])->count();
				$kuota = DokterKuota::find()->where(['iddokter'=>$pelayanan->iddokter])->andwhere(['idhari'=>$hari])->andwhere(['tgl'=>$tgl])->one();
				if($jadwal == 0){
					Yii::$app->session->setFlash('danger', 'Jadwal Dokter Tidak ditemukan');
					return $this->refresh();
				}else{
					if($kuotac == 0 ){
						$newkuota = new DokterKuota();
						$newkuota->iddokter = $pelayanan->iddokter;
						$newkuota->idpoli = $pelayanan->idpoli;
						$newkuota->idhari = $hari;
						$newkuota->tgl = $tgl;
						$newkuota->kuota = $jadwal2->kuota;
						$newkuota->sisa = $jadwal2->kuota - 1;
						$newkuota->terdaftar = 1;
						$newkuota->status = 1;
						$newkuota->save();
					}else{
						if($kuota->sisa == 0){
							Yii::$app->session->setFlash('danger', 'Kuota Habis');
							return $this->refresh();
						}else{
							$kuota->sisa = $kuota->sisa - 1;
							$kuota->terdaftar = $kuota->terdaftar + 1;
							$kuota->save();
						}
						
					}
				}
				$tindakan = Tindakan::findOne(15);
				$tarif = TindakanTarif::find()->where(['idtindakan'=>$tindakan->id])->andWhere(['idbayar'=>$pelayanan->idbayar])->one();
				$trxdetail->idjenispelayanan = 6;
			}else if($pelayanan->idjenisrawat == 3){
				$pelayanan->status = 1;
				$pelayanan->idruangan = 1;
				$tindakan = Tindakan::findOne(16);
				$tarif = TindakanTarif::find()->where(['idtindakan'=>$tindakan->id])->andWhere(['idbayar'=>$pelayanan->idbayar])->one();
				$trxdetail->idjenispelayanan = 15;
			}else{
				// if($pelayanan->idkelas == 1){
					// $tindakan = Tindakan::findOne(38);
					// $tarif = TindakanTarif::find()->where(['idtindakan'=>$tindakan->id])->andWhere(['idbayar'=>$pelayanan->idbayar])->one();
					// $trxdetail->idjenispelayanan = 7;
				// }else if($pelayanan->idkelas == 2){
					// $tindakan = Tindakan::findOne(39);
					// $tarif = TindakanTarif::find()->where(['idtindakan'=>$tindakan->id])->andWhere(['idbayar'=>$pelayanan->idbayar])->one();
					// $trxdetail->idjenispelayanan = 7;
				// }else{
					// $tindakan = Tindakan::findOne(40);
					// $tarif = TindakanTarif::find()->where(['idtindakan'=>$tindakan->id])->andWhere(['idbayar'=>$pelayanan->idbayar])->one();
					// $trxdetail->idjenispelayanan = 7;
				// }
				$bed = RuanganBed::find()->where(['id'=>$pelayanan->idbed])->one();
				$bed->terisi = 1;
				$pelayanan->status = 2;
				$pelayanan->idruangan = $pelayanan->idruangan;
				$kunjungan->status = 2;
				
				$kunjungan->save(false);
				$bed->save(false);
			}
			$tanggal = date('Y-m-d',strtotime('+6 hour',strtotime(date('Y-m-d'))));
			$date1=date_create($model->tgllahir);
			$date2=date_create($tanggal);
			$diff=date_diff($date1,$date2);
			$model->usia_tahun = $diff->format("%y");
			$model->usia_bulan = $diff->format("%m");
			$model->usia_hari = $diff->format("%d");
			$kunjungan->usia_kunjungan = $diff->format("%y");
			$pelayanan->genKode($pelayanan->idjenisrawat);
			$pelayanan->tglmasuk = date('Y-m-d G:i:s',strtotime('+6 hour',strtotime(date('Y-m-d G:i:s'))));
			$pelayanan->iduser = Yii::$app->user->identity->id;
			$pelayanan->kat_pasien = $this->getstatpasien($pelayanan->anggota,$model->idpekerjaan,$pelayanan->idbayar);
			
			//$kuota = $this->kuota_pasien($time,$pelayanan->idpoli,$pelayanan->iddokter);
			if($pelayanan->save(false)){
				if($pelayanan->idjenisrawat == 2){
					$ruangan->idkunjungan = $kunjungan->id;
					$ruangan->idrawat = $pelayanan->id;
					$ruangan->no_rm = $kunjungan->no_rm;
					$ruangan->idruangan = $pelayanan->idruangan;
					$ruangan->idbayar = $pelayanan->idbayar;
					$ruangan->tgl_masuk = date('Y-m-d G:i:s',strtotime('+6 hour',strtotime(date('Y-m-d G:i:s'))));
					$ruangan->status = 1;
					$ruangan->asal = $pelayanan->jenisrawat->jenis;
					$ruangan->save(false);
				}
				if($pelayanan->idjenisrawat != 2 ){
					$trxdetail->idtransaksi = $trx->id;
					$trxdetail->idrawat = $pelayanan->id;
					$trxdetail->idkunjungan = $kunjungan->id;
					$trxdetail->idpelayanan = $tindakan->id;
					$trxdetail->tgl =date('Y-m-d G:i:s',strtotime('+6 hour',strtotime(date('Y-m-d G:i:s'))));
					$trxdetail->nama_tindakan= $tindakan->nama_tindakan;
					$trxdetail->tarif = $tarif->tarif;
					$trxdetail->jumlah = 1;
					$trxdetail->status = 1;
					$trxdetail->total = $tarif->tarif * $trxdetail->jumlah;
					$trxdetail->jenis = $pelayanan->idjenisrawat;
					$trxdetail->idtindakan = $tarif->id;
					$trxdetail->idbayar = $pelayanan->idbayar;
					$trxdetail->save(false);
				}
				
				$model->save(false);
				$kunjungan->save(false);
				return $this->refresh();
			}else{
				return $this->render('rawat-kunjungan',[
					'kunjungan'=>$kunjungan,
					'model'=>$model,
					'pelayanan'=>$pelayanan,
					'bpjs'=>$bpjs,
					'pindah'=>$pindah,
				]);
			}
		}
		return $this->render('rawat-kunjungan',[
			'kunjungan'=>$kunjungan,
			'model'=>$model,
			'pelayanan'=>$pelayanan,
			'bpjs'=>$bpjs,
			'pindah'=>$pindah,
		]);
	}
	public function actionListpoli($id)
	{
		$models=Poli::find()->where(['ket' => $id])->all();

		foreach($models as $k){
		  echo "<option value='".$k->id."'>".$k->poli."</option>";
		}
	}
	public function actionListRuangan($id)
	{
		$models=Ruangan::find()->where(['idkelas' => $id])->all();

		foreach($models as $k){
		  echo "<option value='".$k->id."'>".$k->nama_ruangan."</option>";
		}
	}
	public function actionShowPelayanan($id){
		$rawat = Rawat::find()->where(['id'=>$id])->one();
		$soapdr = SoapRajaldokter::find()->where(['idrawat'=>$rawat->id])->one();
		$soappr = SoapRajalperawat::find()->where(['idrawat'=>$rawat->id])->one();
		$soapicdx = SoapRajalicdx::find()->where(['idrawat'=>$rawat->id])->all();
		$soaplab = SoapLab::find()->where(['idrawat'=>$rawat->id])->all();
		$soaprad = SoapRadiologi::find()->where(['idrawat'=>$rawat->id])->all();
		$soapobat = SoapRajalobat::find()->where(['idrawat'=>$rawat->id])->all();
		return $this->renderAjax('show-pelayanan',[
			'rawat'=>$rawat,
			'soapdr'=>$soapdr,
			'soappr'=>$soappr,
			'soapicdx'=>$soapicdx,
			'soaplab'=>$soaplab,
			'soaprad'=>$soaprad,
			'soapobat'=>$soapobat,
		]);
	}
	public function actionShowRuangan($id){
		$pelayanan = new Rawat();
		$ruangan = RuanganBed::find()->where(['idruangan'=>$id])->andwhere(['terisi'=>0])->all();
		$cruangan = RuanganBed::find()->where(['idruangan'=>$id])->andwhere(['terisi'=>0])->count();;
		return $this->renderAjax('show-ruangan',[
			'ruangan'=>$ruangan,
			'pelayanan'=>$pelayanan,
			'cruangan'=>$cruangan,
		]);
	}
	public function actionShowRuanganPindah($id){
		$rawat = new Rawat();
		$ruangan = RuanganBed::find()->where(['idruangan'=>$id])->andwhere(['terisi'=>0])->all();
		$cruangan = RuanganBed::find()->where(['idruangan'=>$id])->andwhere(['terisi'=>0])->count();;
		return $this->renderAjax('show-ruangan-pindah',[
			'ruangan'=>$ruangan,
			'cruangan'=>$cruangan,
			'rawat'=>$rawat,
		]);
	}
	
	public function actionShowDokter($id,$rm,$jenis,$kunjungan){
		$pelayanan = new Rawat();
		$dokter = DokterJadwal::find()->where(['idpoli'=>$id])->andWhere(['idhari'=>date('N',strtotime($kunjungan))])->all();
		$cdokter = DokterJadwal::find()->where(['idpoli'=>$id])->andWhere(['idhari'=>date('N',strtotime($kunjungan))])->count();
		$cekrajal = Rawat::find()->where(['no_rm'=>$rm])->andWhere(['DATE_FORMAT(tglmasuk,"%Y-%m-%d")'=>$kunjungan])->andwhere(['<>','status','5'])->count(); 
		return $this->renderAjax('show-dokter',[
			'dokter'=>$dokter,
			'cdokter'=>$cdokter,
			'pelayanan'=>$pelayanan,
			'cekrajal'=>$cekrajal,
			'jenis'=>$jenis,
			'kunjungan'=>$kunjungan,
		]);
	}
	
	public function actionGetDokter()
    {
		$kode = Yii::$app->request->post('id');	
		if($kode){
			$model = Dokter::find()->where(['id'=>$kode])->one();
		}else{
			$model = "";
		}
		return \yii\helpers\Json::encode($model);
    }
	public function actionGetBed()
    {
		$kode = Yii::$app->request->post('id');	
		if($kode){
			$model = RuanganBed::find()->where(['id'=>$kode])->one();
		}else{
			$model = "";
		}
		return \yii\helpers\Json::encode($model);
    }
	public function actionGetRanap()
    {
		$kode = Yii::$app->request->post('id');	
		if($kode){
			$model = Rawat::find()->where(['id'=>$kode])->one();
		}else{
			$model = "";
		}
		return \yii\helpers\Json::encode($model);
    }
    public function actionView($id)
    {
		if(Yii::$app->user->isGuest){
			return $this->redirect(['site/index']);
		}
		$trx = new Transaksi();
		$model = $this->findModel($id);
		$list_rawat = Rawat::find()->where(['no_rm'=>$model->no_rm])->andwhere(['<>','status',5])->orderBy(['tglmasuk'=>SORT_DESC])->limit(10)->all();
		$list_kunjungan = RawatKunjungan::find()->where(['no_rm'=>$model->no_rm])->andwhere(['<>','status',5])->orderBy(['tgl_kunjungan'=>SORT_DESC])->limit(5)->all();
		$kode = $model->no_bpjs;
		$time = date('Y-m-d');
		$kunjungan = new RawatKunjungan();
		$trxdetail = new TransaksiDetail();
		$pelayanan = new Rawat();
		
		// $response= Yii::$app->vclaim->get_peserta($kode,$time);
		// $peserta = $response['response'];
		// $bpjs = $peserta['peserta'];
		if ($pelayanan->load($this->request->post())) {
			$tgl = date('Y-m-d',strtotime($pelayanan->tglmasuk));
			$hari = date('N',strtotime($pelayanan->tglmasuk));
			$kunjungan = RawatKunjungan::find()->where(['no_rm'=>$model->no_rm])->andwhere(['tgl_kunjungan'=>date('Y-m-d',strtotime($pelayanan->tglmasuk))])->one();
			$tanggal = date('Y-m-d',strtotime('+6 hour',strtotime(date('Y-m-d H:i:s'))));
			$date1=date_create($model->tgllahir);
			$date2=date_create($tanggal);
			$diff=date_diff($date1,$date2);
			if($kunjungan){
				$pelayanan->idkunjungan = $kunjungan->idkunjungan;
				$kunjungan->usia_kunjungan = $diff->format("%y");
				$trxdetail->idkunjungan = $kunjungan->id;
			}else{
				$new_kunjungan = new RawatKunjungan();
				$new_kunjungan->genKode();
				$new_kunjungan->iduser = Yii::$app->user->identity->id;
				$new_kunjungan->usia_kunjungan = $model->usia_tahun;
				$new_kunjungan->no_rm = $model->no_rm;
				$new_kunjungan->tgl_kunjungan = date('Y-m-d',strtotime($pelayanan->tglmasuk));
				$new_kunjungan->jam_kunjungan = date('G:i:s',strtotime('+6 hour',strtotime(date('G:i:s'))));
				$new_kunjungan->usia_kunjungan = $diff->format("%y");
				$new_kunjungan->status = 1;
				$trx->genKode();
				if($new_kunjungan->save(false)){
					$trxdetail->idkunjungan = $new_kunjungan->id;
					$trx->idkunjungan = $new_kunjungan->id;
					$trx->kode_kunjungan = $new_kunjungan->idkunjungan;
					$trx->no_rm = $model->no_rm;
					$trx->tgltransaksi = $new_kunjungan->tgl_kunjungan.' '.$new_kunjungan->jam_kunjungan ;
					$trx->tgl_masuk = $new_kunjungan->tgl_kunjungan;
					$trx->status =1;
					$trx->save(false);
				}
				$pelayanan->idkunjungan = $new_kunjungan->idkunjungan;
			}
			if($pelayanan->idjenisrawat == 1){
				$pelayanan->status = 1;
				$pelayanan->idruangan = 2;
				$pelayanan->genAntri($pelayanan->idpoli,$pelayanan->iddokter,$pelayanan->anggota,date('Y-m-d',strtotime($pelayanan->tglmasuk)));
				$jadwal = DokterJadwal::find()->where(['iddokter'=>$pelayanan->iddokter])->andwhere(['idhari'=>$hari])->count();
				$jadwal2 = DokterJadwal::find()->where(['iddokter'=>$pelayanan->iddokter])->andwhere(['idhari'=>$hari])->one();
				$kuotac = DokterKuota::find()->where(['iddokter'=>$pelayanan->iddokter])->andwhere(['idhari'=>$hari])->andwhere(['tgl'=>$tgl])->count();
				$kuota = DokterKuota::find()->where(['iddokter'=>$pelayanan->iddokter])->andwhere(['idhari'=>$hari])->andwhere(['tgl'=>$tgl])->one();
				if($jadwal == 0){
					Yii::$app->session->setFlash('danger', 'Jadwal Dokter Tidak ditemukan');
					return $this->refresh();
				}else{
					if($kuotac == 0 ){
						$newkuota = new DokterKuota();
						$newkuota->iddokter = $pelayanan->iddokter;
						$newkuota->idpoli = $pelayanan->idpoli;
						$newkuota->idhari = $hari;
						$newkuota->tgl = $tgl;
						$newkuota->kuota = $jadwal2->kuota;
						$newkuota->sisa = $jadwal2->kuota - 1;
						$newkuota->terdaftar = 1;
						$newkuota->status = 1;
						$newkuota->save();
					}else{
						if($kuota->sisa == 0){
							Yii::$app->session->setFlash('danger', 'Kuota Habis');
							return $this->refresh();
						}else{
							$kuota->sisa = $kuota->sisa - 1;
							$kuota->terdaftar = $kuota->terdaftar + 1;
							$kuota->save();
						}
						
					}
				}
				// $tindakan = Tindakan::findOne(15);
				// $tarif = TindakanTarif::find()->where(['idtindakan'=>$tindakan->id])->andWhere(['idbayar'=>$pelayanan->idbayar])->one();
				// $trxdetail->idjenispelayanan = 6;
			}else if($pelayanan->idjenisrawat == 3){
				$pelayanan->status = 1;
				$pelayanan->idruangan = 1;
				$tindakan = Tindakan::findOne(16);
				// $tarif = TindakanTarif::find()->where(['idtindakan'=>$tindakan->id])->andWhere(['idbayar'=>$pelayanan->idbayar])->one();
				// $trxdetail->idjenispelayanan = 15;
			}
			
			$model->usia_tahun = $diff->format("%y");
			$model->usia_bulan = $diff->format("%m");
			$model->usia_hari = $diff->format("%d");
			$model->kunjungan_terakhir = date('Y-m-d',strtotime('+6 hour',strtotime(date('Y-m-d H:i:s'))));
			$pelayanan->tglmasuk = $pelayanan->tglmasuk.' '.date('G:i:s',strtotime('+5 hour',strtotime(date('G:i:s'))));
			$pelayanan->genKode($pelayanan->idjenisrawat);
			$pelayanan->status = 1;
			$pelayanan->kat_pasien = $this->getstatpasien($pelayanan->anggota,$model->idpekerjaan,$pelayanan->idbayar);
			$pelayanan->iduser = Yii::$app->user->identity->id;
			if($pelayanan->save(false)){
					$tarif = Tarif::findOne(11);
					$tarif_trx = new TransaksiDetailRinci();
					$tarif_trx->idrawat = $pelayanan->id;
					$tarif_trx->idpaket = 0;
					$tarif_trx->idtransaksi = $trx->id;
					$tarif_trx->idtarif = $tarif->id;
					$tarif_trx->idbayar = $pelayanan->idbayar;
					$tarif_trx->iddokter = $pelayanan->iddokter;
					$tarif_trx->tarif = $tarif->tarif; 
					$tarif_trx->tgl = date('Y-m-d',strtotime('+6 hour',strtotime(date('Y-m-d H:i:s'))));
					$tarif_trx->save(false);
					$model->save(false);
					return $this->refresh();
			}
		}
        return $this->render('view', [
            'model' => $model,
            'list_rawat' => $list_rawat,
            'kunjungan' => $kunjungan,
            //'bpjs' => $bpjs,
            'list_kunjungan' => $list_kunjungan,
            'pelayanan' => $pelayanan,
        ]);
    }
	//Update Alamat
	public function actionEditAlamat($id){
		if(Yii::$app->user->isGuest){
			return $this->redirect(['site/logout']);
		}
		
		$model = $this->findAlamat($id);
		$pasien = Pasien::find()->where(['id'=>$model->idpasien])->one();
			if ($model->load($this->request->post())){
				$pasien->idkelurahan = $model->idkel;
				if($model->save(false)){
					$pasien->save(false);
					return $this->redirect(['pasien/'.$model->idpasien]);
				}
			}
	
		return $this->render('edit-alamat',[
			'model'=>$model,
		]);
	}
	//Delete Alamat
	public function actionDeleteAlamat($id)
    {
		if(Yii::$app->user->isGuest){
			return $this->redirect(['site/logout']);
		}
        $this->findAlamat($id)->delete();

        return $this->redirect(Yii::$app->request->referrer);
    }
	//Tambah Alamat
	public function actionTambahAlamat($id){
		if(Yii::$app->user->isGuest){
			return $this->redirect(['site/logout']);
		}
		if(Yii::$app->user->identity->idpriv != 8){
			return $this->redirect(['site/index']);
		}
		$model = $this->findModel($id);
		$alamat = new PasienAlamat();
		if ($this->request->isPost) {
			if ($alamat->load($this->request->post())) {
				$alamat->idpasien = $model->id;
				$response = Yii::$app->kazo->content_noid('https://simrs.rsausulaiman.com/apites/alamat-id?q='.$alamat->idkel);
				$alm = json_decode($response, true);
				$alamat->idprov = $alm['response']['IdProv'];
				$alamat->idkab = $alm['response']['IdKab'];
				$alamat->idkec = $alm['response']['IdKec'];
				if($alamat->save(false)){
					return $this->redirect(['pasien/'.$model->id]);
				}
			}
		}
		return $this->render('tambah-alamat',[
			'model'=>$model,
			'alamat'=>$alamat,
		]);
	}
	//Update PAsien
	public function actionEditPasien($id){
		if(Yii::$app->user->isGuest){
			return $this->redirect(['site/logout']);
		}
		if(Yii::$app->user->identity->idpriv != 8){
			return $this->redirect(['site/index']);
		}
		$model = $this->findModel($id);
		$modelstatus = PasienStatus::find()->where(['idpasien'=>$model->id])->one();

				if ($model->load($this->request->post())) {
					if($model->kodepasien == null){
						$model->genKode();
					}
					$model->idusia = $this->jenjang_usia($model->barulahir,$model->usia_tahun);
					$model->no_rm = substr($model->kodepasien,2);
					$tanggal = date('Y-m-d',strtotime('+6 hour',strtotime(date('Y-m-d'))));
					$date1=date_create($model->tgllahir);
					$date2=date_create($tanggal);
					$diff=date_diff($date1,$date2);
					$model->usia_tahun = $diff->format("%y");
					$model->usia_bulan = $diff->format("%m");
					$model->usia_hari = $diff->format("%d");
					$model->tgldaftar = date('Y-m-d H:i:s');
					$modelstatus->nrp = $model->nrp;
					$modelstatus->kesatuan = $model->kesatuan;
					$modelstatus->pangkat = $model->pangkat;
					if($model->save(false)){
						$modelstatus->save(false);
						return $this->redirect(['pasien/'.$model->id]);
					}
				}
				
		return $this->render('edit-pasien',[
			'model'=>$model,
			'modelstatus'=>$modelstatus,
		]);
	}
	//Create PAsien
    public function actionCreate()
    {
		if(Yii::$app->user->isGuest){
			return $this->redirect(['site/logout']);
		}
		if(Yii::$app->user->identity->idpriv != 8){
			return $this->redirect(['site/index']);
		}
        $model = new Pasien();
        $modelalamat = new PasienAlamat();
        $modelstatus = new PasienStatus();

            if ($model->load($this->request->post())&&$modelalamat->load($this->request->post())&&$modelstatus->load($this->request->post())&&Model::validateMultiple([$model])) {
				if($model->kodepasien == null){
					$model->genKode();
				}
				$model->no_rm = substr($model->kodepasien,2);
				$cek_rm = Pasien::find()->where(['no_rm'=>$model->no_rm])->count();
				if($cek_rm > 0){
					$rm_pasien =  (substr($model->no_rm,1));
					$norm = rm_pasien+1;
					$rm = 0;
					$model->no_rm = $rm.$no_rm;
					$model->kodepasien = 'P-'.$model->no_rm;
				}
				if($modelalamat->idkel == null){
					Yii::$app->session->setFlash('danger', 'Kelurahan tidak boleh kosong');
					return $this->refresh();
				}
				if($model->nik == null){
					date_default_timezone_set('UTC');
					$tStamp = strval(time()-strtotime('1970-01-01 00:00:00'));
					$model->nik = $tStamp.$model->no_rm;
				}
				if($model->no_bpjs == null){
					date_default_timezone_set('UTC');
					$tStamp = strval(time()-strtotime('1970-01-01 00:00:00'));
					$model->no_bpjs = $tStamp.$model->no_rm;
				}
				$response = Yii::$app->kazo->content_noid('https://simrs.rsausulaiman.com/apites/alamat-id?q='.$modelalamat->idkel);
				$alamat = json_decode($response, true);

				$model->iduser = Yii::$app->user->identity->id;
				
				
				$tanggal = date('Y-m-d',strtotime('+5 hour',strtotime(date('Y-m-d'))));
				
				$date1=date_create($model->tgllahir);
				$date2=date_create($tanggal);
				$diff=date_diff($date1,$date2);
				$model->usia_tahun = $diff->format("%y");
				$model->usia_bulan = $diff->format("%m");
				$model->usia_hari = $diff->format("%d");
				$model->tgldaftar = date('Y-m-d G:i:s',strtotime('+5 hour',strtotime(date('Y-m-d G:i:s'))));
				$model->kunjungan_terakhir = date('Y-m-d',strtotime('+5 hour',strtotime(date('Y-m-d'))));
				$model->jamdaftar = date('G:i:s',strtotime('+5 hour',strtotime(date('G:i:s'))));
				$model->status = 1;
				$model->idusia = $this->jenjang_usia($model->barulahir,$model->usia_tahun);
				
				$modelalamat->idprov = $alamat['response']['IdProv'];
				$modelalamat->idkab = $alamat['response']['IdKab'];
				$modelalamat->idkec = $alamat['response']['IdKec'];
				$modelalamat->utama = 1;
				$model->nrp = $modelstatus->nrp;
				$model->kesatuan = $modelstatus->kesatuan;
				$model->pangkat = $modelstatus->pangkat;
				$model->status_pasien = $modelstatus->idstatus;
				$model->idkelurahan = $modelalamat->idkel;
				if($model->save(false)){
					$modelstatus->idpasien = $model->id;
					$modelalamat->idpasien = $model->id;
					$modelalamat->save(false);
					$modelstatus->save(false);
					return $this->redirect(['view', 'id' => $model->id]);
				}else{
					Yii::$app->session->setFlash('danger', 'Data Gagal Tersimpans');
					return $this->refresh();
				}
            }
 

        return $this->render('create', [
            'model' => $model,
            'modelalamat' => $modelalamat,
            'modelstatus' => $modelstatus,
        ]);
    }
	//sep
	public function actionSep($id,$rujukan,$tgl,$poli,$faskes=''){
		$rawat = Rawat::findOne($id);
		$date = date('Y-m-d',strtotime($rawat->tglmasuk));
		$date3=date_create(date('Y-m-d'));
		$date4=date_create($date);
		$diff2=date_diff($date3,$date4);
		$selisih2 = $diff2->format("%d");
		$date1=date_create($tgl);
		$date2=date_create($date);
		$diff=date_diff($date1,$date2);
		$selisih = $diff->format("%m");
		if($selisih > 2){
			Yii::$app->session->setFlash('danger', 'Rujukan Sudah habis');
			return $this->redirect(Yii::$app->request->referrer);
		}
		$rawat = Rawat::findOne($id);
		$pasien = Pasien::find()->where(['no_rm'=>$rawat->no_rm])->one();
		if($faskes == 1){
			$response= Yii::$app->vclaim->get_rujukan($rujukan);
		}else{
			$response= Yii::$app->vclaim->get_rujukanrs($rujukan);
		}
		$url = Yii::$app->params['baseUrl'].'dashboard//rest/monitoring-kunjungan?norujukan='.$rujukan.'&awal='.$response['response']['rujukan']['tglKunjungan'].'&akhir='.$date.'&nokartu='.$pasien->no_bpjs.'&poli='.$poli;
		$content = file_get_contents($url);
		$json = json_decode($content, true);
		// return print_r;
		if($json['metaData']['code'] == 200){
			$jumlah = count($json);
		}else{
			$jumlah = 0;
		}

		return $this->render('sep',[
			'rawat'=>$rawat,
			'pasien'=>$pasien,
			'rujukan'=>$response,
			'selisih2'=>$selisih2,
			'jumlah'=>$jumlah,
		]);
		
	}
	public function actionSepManual($id,$tgl){
		$rawat = Rawat::findOne($id);
		$date = date('Y-m-d',strtotime($rawat->tglmasuk));
		$date3=date_create(date('Y-m-d'));
		$date4=date_create($date);
		$diff2=date_diff($date3,$date4);
		$selisih2 = $diff2->format("%d");		
		$rawat = Rawat::findOne($id);
		$pasien = Pasien::find()->where(['no_rm'=>$rawat->no_rm])->one();
		return $this->render('sep-manual',[
			'rawat'=>$rawat,
			'selisih2'=>$selisih2,
		]);
		
	}
	public function actionLabelPasien($id,$jumlah) {
		if(Yii::$app->user->isGuest){
		return $this->redirect(['site/logout']);
		}
		$model = RawatKunjungan::find()->where(['id' =>$id ])->one();
		$content = $this->renderPartial('label-kunjungan',['model' => $model ,'jumlah'=>$jumlah]);
		  // setup kartik\mpdf\Pdf component
		$pdf = new Pdf([
		   'mode' => Pdf::MODE_CORE,
		   'destination' => Pdf::DEST_BROWSER,
		    'format' => [50,20],
		   'marginTop' => '2',
		   'orientation' => Pdf::ORIENT_PORTRAIT, 
		   'marginLeft' => '0',
		   'marginRight' => '0',
		   'marginBottom' => '2',
		   'content' => $content,  
		   'cssFile' => '@frontend/web/css/paper-pasien.css',
		   //'options' => ['title' => 'Bukti Permohonan Informasi'],
		]);
		$response = Yii::$app->response;
		$response->format = \yii\web\Response::FORMAT_RAW;
		$headers = Yii::$app->response->headers;
		$headers->add('Content-Type', 'application/pdf');

	// return the pdf output as per the destination setting
	return $pdf->render(); 
	}
	public function actionGelang($id) {
		if(Yii::$app->user->isGuest){
		return $this->redirect(['site/logout']);
		}
		$model = Rawat::find()->where(['id' =>$id ])->one();
		$content = $this->renderPartial('gelang',['model' => $model]);
		  // setup kartik\mpdf\Pdf component
		$pdf = new Pdf([
		   'mode' => Pdf::MODE_CORE,
		   'destination' => Pdf::DEST_BROWSER,
		   'format' => [100,25],
		   'marginTop' => '3',
		   'orientation' => Pdf::ORIENT_PORTRAIT, 
		   'marginLeft' => '4',
		   'marginRight' => '4',
		   'marginBottom' => '3',
		   'content' => $content,  
		   'cssFile' => '@frontend/web/css/paper-pasien.css',
		   //'options' => ['title' => 'Bukti Permohonan Informasi'],
		]);
		$response = Yii::$app->response;
		$response->format = \yii\web\Response::FORMAT_RAW;
		$headers = Yii::$app->response->headers;
		$headers->add('Content-Type', 'application/pdf');

	// return the pdf output as per the destination setting
	return $pdf->render(); 
	}
	public function actionBarcodePasien($id,$jumlah) {
		if(Yii::$app->user->isGuest){
		return $this->redirect(['site/logout']);
		}
		$model = RawatKunjungan::find()->where(['id' =>$id ])->one();
		$content = $this->renderPartial('barcode-kunjungan',['model' => $model ,'jumlah'=>$jumlah]);
		  // setup kartik\mpdf\Pdf component
		$pdf = new Pdf([
		   'mode' => Pdf::MODE_CORE,
		   'destination' => Pdf::DEST_BROWSER,
		    'format' => [50,20],
		   'marginTop' => '2',
		   'orientation' => Pdf::ORIENT_PORTRAIT, 
		   'marginLeft' => '0',
		   'marginRight' => '0',
		   'marginBottom' => '2',
		   'content' => $content,  
		   'cssFile' => '@frontend/web/css/paper-pasien.css',
		   //'options' => ['title' => 'Bukti Permohonan Informasi'],
		]);
		$response = Yii::$app->response;
		$response->format = \yii\web\Response::FORMAT_RAW;
		$headers = Yii::$app->response->headers;
		$headers->add('Content-Type', 'application/pdf');

	// return the pdf output as per the destination setting
	return $pdf->render(); 
	}
	public function actionBarcodeKartu($id) {
	//tampilkan bukti proses
	if(Yii::$app->user->isGuest){
		return $this->redirect(['site/logout']);
	}
	$model = Pasien::find()->where(['id' =>$id ])->one();
	$alamat = PasienAlamat::find()->where(['idpasien'=>$model->id])->andwhere(['utama'=>1])->one();
	$content = $this->renderPartial('barcode-kartu',['model' => $model,'alamat'=>$alamat]);
	  // setup kartik\mpdf\Pdf component
	$pdf = new Pdf([
	   'mode' => Pdf::MODE_CORE,
	   'destination' => Pdf::DEST_BROWSER,
	   'format' => [50,20],
		   'marginTop' => '2',
		   'orientation' => Pdf::ORIENT_PORTRAIT, 
		   'marginLeft' => '0',
		   'marginRight' => '0',
		   'marginBottom' => '2',
	   'content' => $content,  
	   'cssFile' => '@frontend/web/css/paper-pasien.css',
	   //'options' => ['title' => 'Bukti Permohonan Informasi'],
	]);
	$response = Yii::$app->response;
	$response->format = \yii\web\Response::FORMAT_RAW;
	$headers = Yii::$app->response->headers;
	$headers->add('Content-Type', 'application/pdf');

	// return the pdf output as per the destination setting
	return $pdf->render(); 
	}
	//Print Form Pasien
	public function actionFormPasien($id) {
	  //tampilkan bukti proses
		if(Yii::$app->user->isGuest){
			return $this->redirect(['site/logout']);
		}
	  $model = Pasien::find()->where(['id' =>$id ])->one();
	  $content = $this->renderPartial('form-pasien',['model' => $model]);
	  
	  // setup kartik\mpdf\Pdf component
	  $pdf = new Pdf([
	   'mode' => Pdf::MODE_CORE,
	   'destination' => Pdf::DEST_BROWSER,
	   'format' => Pdf::FORMAT_A4, 
	   'content' => $content,  
	   
	   'cssFile' => '@frontend/web/css/paper.css',
	   //'options' => ['title' => 'Bukti Permohonan Informasi'],

		'methods' => [ 
            'SetFooter'=>['DRM. 01 - RJ'],
        ]	   ]);
		 $response = Yii::$app->response;
			$response->format = \yii\web\Response::FORMAT_RAW;
			$headers = Yii::$app->response->headers;
			$headers->add('Content-Type', 'application/pdf');
	  
	  // return the pdf output as per the destination setting
	  return $pdf->render(); 
	}
	
	//Get Data Pasien
	public function actionGetPasien()
    {
		$kode = Yii::$app->request->post('id');	
		if($kode){
			$time = date('Y-m-d');
			$response= Yii::$app->vclaim->get_peserta($kode,$time);
			$peserta = $response['response'];
			$model = $peserta['peserta'];
			
		}else{
			$model = "";
		}
		return \yii\helpers\Json::encode($model);
    }

    /**
     * Updates an existing Pasien model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $id ID
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);$model = $this->findModel($id);
    }
	 public function actionTesVclaim(){
		$response= Yii::$app->vclaim->get_rujukan('0001391429979');
		$model = $response['response'];
		return \yii\helpers\Json::encode($response);
	 }
    /**
     * Deletes an existing Pasien model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $id ID
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Pasien model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param int $id ID
     * @return Pasien the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Pasien::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
	protected function findAlamat($id)
    {
        if (($model = PasienAlamat::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
