<?php

namespace backend\controllers;

use Yii;
use common\models\Rawat;
use common\models\RawatKunjungan;
use common\models\Pasien;
use common\models\RawatSpri;
use common\models\Transaksi;
use common\models\Tarif;
use common\models\Tindakan;
use common\models\TindakanTarif;
use common\models\RuanganBed;
use common\models\RawatRuangan;
use common\models\RawatPermintaanPindahSearch;
use common\models\RawatPermintaanPindah;
use common\models\RawatSpriSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use kartik\mpdf\Pdf;
/**
 * RawatBayarController implements the CRUD actions for RawatBayar model.
 */
class AdmisiController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all RawatBayar models.
     * @return mixed
     */
	function getstatpasien($anggota='',$idpekerjaan='',$idbayar=''){
		if($anggota == 1){
			if($idpekerjaan == 1){
				return 1;
			}else if($idpekerjaan == 2){
				return 2;
			}else{
				return 3;
			}
		}else{
			if($idpekerjaan == 3){
				return 4;
			}else if($idpekerjaan == 4){
				return 5;
			}else if($idpekerjaan == 17){
				return 6;
			}else{
				if($idbayar == 2){
					return 7;
				}else{
					return 8;
				}
			}
		}
	}
    public function actionTes(){
		$response= Yii::$app->vclaim->get_dokter('adit');
		return \yii\helpers\Json::encode($response);
	}
    public function actionCreate(){
		$spri = new RawatSpri();
		if($spri->load(Yii::$app->request->post())){
			$spri->status = 1;
			$spri->idpoli = $spri->dokter->idpoli;
			$spri->kode_dokter = $spri->dokter->kode_dpjp;
			$spri->genKode();
			$spri->iduser = Yii::$app->user->identity->id;
			// $arrdip= json_encode(array(
           // "request" => array(
					// "noKartu"=>$spri->pasien->no_bpjs,
                    // "kodeDokter"=>$spri->kode_dokter,
                    // "poliKontrol"=>$spri->poli->kode,
                    // "tglRencanaKontrol"=>$spri->tgl_rawat,
                    // "user"=>"sss"
		   // )));
			// $response= Yii::$app->kazo->bpjs_content(Yii::$app->params['baseUrlBpjs'].'RencanaKontrol/InsertSPRI',$arrdip);
			// $data_json=json_decode($response, true);
			// return print_r($data_json);
			if($spri->save(false)){
				//Yii::$app->vclaim->post_spri($spri->id);
				Yii::$app->session->setFlash('success', "Data tersimpan pasien dijadwalkan masuk rawat inap Tgl ".$spri->tgl_rawat."Nomor Spri".$spri->no_spri); 
				return $this->redirect(['admisi/index']);
			}
			
		}
		return $this->render('create',[
			'spri'=>$spri,
		]);
	}
    public function actionIndex()
    {
		$url = Yii::$app->params['baseUrl']."dashboard/rest/bed";
		$content = file_get_contents($url);
		$json = json_decode($content, true);
		$tgl = date('Y-m-d',strtotime('+6 hour',strtotime(date('Y-m-d H:i:s'))));
		$where = ['tgl_rawat'=>$tgl];
		$andWhere = ['status'=>1];
		$searchModel = new RawatSpriSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams,$where,$andWhere);
		
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'bed' => $json,
        ]);
    }
	public function actionIndexSelesai()
    {
		
		$url = Yii::$app->params['baseUrl']."dashboard/rest/bed";
		$content = file_get_contents($url);
		$json = json_decode($content, true);
		$tgl = date('Y-m-d');
		$tgl = date('Y-m-d');
		$where = ['status'=>2];
		$searchModel = new RawatSpriSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams,$where);
		
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
			'bed' => $json,
        ]);
		
    }
	public function actionIndexSemua()
    {
		
		$url = Yii::$app->params['baseUrl']."dashboard/rest/bed";
		$content = file_get_contents($url);
		$json = json_decode($content, true);
		$tgl = date('Y-m-d');
		$tgl = date('Y-m-d');
		$searchModel = new RawatSpriSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
		
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
			'bed' => $json,
        ]);
	}
	public function actionPindahRuangan(){
		$where = ['status'=>1];
		$searchModel = new RawatPermintaanPindahSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams,$where);
		
        return $this->render('pindah-ruangan', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
	}
	public function actionPindah($id){
		$model = RawatPermintaanPindah::findOne($id);
		$pasien = Pasien::find()->where(['no_rm'=>$model->no_rm])->one();
		$rawat = Rawat::findOne($model->idrawat);
		$transaksi = Transaksi::find()->where(['idkunjungan'=>$rawat->kunjungans->id])->one();
		$tgl = date('Y-m-d G:i:s',strtotime('+5 hour',strtotime(date('Y-m-d G:i:s'))));
		$ruangan = new RawatRuangan();
		$ruangan_asal = RawatRuangan::find()->where(['idrawat'=>$rawat->id])->andwhere(['status'=>1])->one();
		$bed = RuanganBed::findOne($rawat->idbed);
		if($rawat->load($this->request->post()) && $ruangan->load($this->request->post())) {
			$ruangan_asal->status = 2;
			$ruangan_asal->tgl_keluar = date('Y-m-d G:i:s',strtotime('+5 hour',strtotime(date('Y-m-d G:i:s'))));
			$bed2 = RuanganBed::findOne($rawat->idbed);
			$date1=date_create($ruangan_asal->tgl_keluar);
			$date2=date_create($ruangan_asal->tgl_masuk);
			$diff=date_diff($date1,$date2);
			$ruangan_asal->los = $diff->format("%d") + 1;
			$bed->terisi = 0;
			$bed2->terisi = 1;
			// if($ruangan_asal->idkelas == 1){
				// $tindakan = Tindakan::findOne(38);
				// $tarif = TindakanTarif::find()->where(['idtindakan'=>$tindakan->id])->andWhere(['idbayar'=>$ruangan_asal->idbayar])->one();
			// }else if($ruangan_asal->idkelas == 2){
				// $tindakan = Tindakan::findOne(39);
				// $tarif = TindakanTarif::find()->where(['idtindakan'=>$tindakan->id])->andWhere(['idbayar'=>$ruangan_asal->idbayar])->one();
			// }else{
				// $tindakan = Tindakan::findOne(40);
				// $tarif = TindakanTarif::find()->where(['idtindakan'=>$tindakan->id])->andWhere(['idbayar'=>$ruangan_asal->idbayar])->one();
			// }
			$tarif_ruangan = Tarif::find()->where(['nama_tarif'=>'Kamar'])->andwhere(['idkelas'=>$ruangan_asal->idkelas])->andwhere(['idruangan'=>$ruangan_asal->idruangan])->one();
			if($ruangan_asal->save(false)){
				$bed->save(false);
				Yii::$app->kazo->tranruanganrinci($transaksi->id,$rawat->id,$ruangan_asal->tgl_keluar,$tarif_ruangan->id,$tarif_ruangan->tarif,$ruangan_asal->idbayar,$ruangan_asal->los);
				Yii::$app->vclaim->updateKamar();
				$model->status = 2;
				$model->save();
				$ruangan->status = 1;
				$ruangan->idbed = $rawat->idbed;
				$ruangan->idkelas = $rawat->idkelas;
				$ruangan->idruangan = $rawat->idruangan;
				$ruangan->tgl_masuk = date('Y-m-d G:i:s',strtotime('+5 hour',strtotime(date('Y-m-d G:i:s'))));
				$ruangan->asal ='Rawat Inap';
				if($ruangan->save(false)){
					$rawat->save(false);
					$bed2->save(false);
					return $this->redirect(['admisi/index']);
				}
			}
		}
		// return $ruangan_asal->status;
		return $this->render('pindah',[
			'model'=>$model,
			'pasien'=>$pasien,
			'rawat'=>$rawat,
			'ruangan'=>$ruangan,
		]);
	}
	public function actionView($id){
		$model = $this->findModel($id);
		$rawat = new Rawat();
		$new_kunjungan = new RawatKunjungan();
		$ruangan = new RawatRuangan();
		$transaksi = new Transaksi();
		$pasien = Pasien::find()->where(['no_rm'=>$model->no_rm])->one();
		$time = date('Y-m-d');
		$response= Yii::$app->vclaim->get_peserta($pasien->no_bpjs,$time);
		if ($rawat->load($this->request->post())) {
			$kunjungan = RawatKunjungan::find()->where(['no_rm'=>$model->no_rm])->andwhere(['tgl_kunjungan'=>$model->tgl_rawat])->one();
			if($kunjungan){
				$rawat->idkunjungan = $kunjungan->idkunjungan;
				$ruangan->idkunjungan = $kunjungan->id;
			}else{
				$new_kunjungan->genKode();
				$new_kunjungan->iduser = Yii::$app->user->identity->id;
				$new_kunjungan->usia_kunjungan = $pasien->usia_tahun;
				$new_kunjungan->no_rm = $model->no_rm;
				$new_kunjungan->tgl_kunjungan = $model->tgl_rawat;
				$new_kunjungan->jam_kunjungan = date('G:i:s',strtotime('+5 hour',strtotime(date('G:i:s'))));
				$new_kunjungan->status = 1;
				
				if($new_kunjungan->save(false)){
					$ruangan->idkunjungan = $new_kunjungan->id;
					$transaksi->genKode();
					$transaksi->idkunjungan = $new_kunjungan->id;
					$transaksi->kode_kunjungan = $new_kunjungan->idkunjungan;
					$transaksi->no_rm = $model->no_rm;
					$transaksi->tgltransaksi = $new_kunjungan->tgl_kunjungan.' '.$new_kunjungan->jam_kunjungan ;
					$transaksi->tgl_masuk = $new_kunjungan->tgl_kunjungan;
					$transaksi->status =1;
					$transaksi->save(false);
				}
				$rawat->idkunjungan = $new_kunjungan->idkunjungan;
			}
			$rawat->genKode(2);
			$rawat->tglmasuk = date('Y-m-d G:i:s',strtotime('+5 hour',strtotime(date('Y-m-d G:i:s'))));
			$rawat->status = 2;
			$rawat->kat_pasien = $this->getstatpasien($rawat->anggota,$pasien->idpekerjaan,$rawat->idbayar);
			$rawat->iduser = Yii::$app->user->identity->id;
			if($rawat->save(false)){
				$model->status = 2;
				$model->save(false);
				$bed = RuanganBed::find()->where(['id'=>$rawat->idbed])->one();
				$bed->terisi = 1;
				if($bed->save(false)){
					Yii::$app->vclaim->updateKamar();
					$ruangan->idbed = $rawat->idbed;
					$ruangan->idkelas = $rawat->idkelas;
					$ruangan->idrawat = $rawat->id;
					$ruangan->no_rm = $pasien->no_rm;
					$ruangan->idruangan = $rawat->idruangan;
					$ruangan->idbayar = $rawat->idbayar;
					$ruangan->tgl_masuk = date('Y-m-d G:i:s',strtotime('+6 hour',strtotime(date('Y-m-d G:i:s'))));
					$ruangan->status = 1;
					$ruangan->asal = $rawat->jenisrawat->jenis;
					$ruangan->save(false);
					return $this->redirect(['pasien/'.$model->pasien->id]);
				}
			}
		}
		return $this->render('view',[
			'model'=>$model,
			'pasien'=>$pasien,
			'rawat'=>$rawat,
			'bpjs'=>$response,
		]);
	}
	public function actionShowRuangan($id){
		$pelayanan = new Rawat();
		$ruangan = RuanganBed::find()->where(['idruangan'=>$id])->andwhere(['terisi'=>0])->all();
		$cruangan = RuanganBed::find()->where(['idruangan'=>$id])->andwhere(['terisi'=>0])->count();;
		return $this->renderAjax('show-ruangan',[
			'ruangan'=>$ruangan,
			'pelayanan'=>$pelayanan,
			'cruangan'=>$cruangan,
		]);
	}
	public function actionShowPasien($id){
		$spri = new RawatSpri();
		$pasien = Pasien::find()->where(['no_rm'=>$id])->one();
		
		return $this->renderAjax('show-pasien',[
			'pasien'=>$pasien,
			'spri'=>$spri,
		]);
	}
    /**
     * Deletes an existing RawatBayar model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the RawatBayar model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return RawatBayar the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = RawatSpri::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
