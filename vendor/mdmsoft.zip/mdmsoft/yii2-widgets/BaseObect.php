<?php

namespace mdm\widgets;

if(!class_exists('yii\base\BaseObject')){
    class_alias('yii\base\Object', 'yii\base\BaseObject');
}

/**
 * Description of BaseObect
 *
 * @author Misbahul D Munir <misbahuldmunir@gmail.com>
 * @since 1.3
 */
class BaseObect extends \yii\base\BaseObject
{
    
}
